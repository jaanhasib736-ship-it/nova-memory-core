import { saveSafFolderHandle, loadSafFolderHandles, type StoredSafFolder } from '../db/idbStorage';
import {
  beginOperationJournal,
  completeOperationJournal,
  getDatabaseHealth,
  getSetting,
  listDocuments,
  listMemories,
  logArchiveAction,
  registerDocument,
  updateDocument,
  updateMemory,
} from '../db/sqliteEngine';
import type {
  ArchiveSuggestion,
  DocumentRecord,
  DuplicateGroup,
  StorageReport,
  StorageSource,
} from '../types/nova';
import { computeSHA256 } from './cryptoService';

declare global {
  interface Window {
    showDirectoryPicker?: (options?: { mode?: 'read' | 'readwrite' }) => Promise<FileSystemDirectoryHandle>;
    showOpenFilePicker?: (options?: { multiple?: boolean }) => Promise<FileSystemFileHandle[]>;
    NovaAndroidBridge?: {
      pickSafDirectory?: () => void;
      getDeviceStorageStats?: () => string;
      authenticateBiometric?: () => boolean;
      scheduleArchiveWorker?: (days: number) => boolean;
    };
  }
}

export function isSafDirectoryPickerSupported(): boolean {
  return typeof window !== 'undefined' && typeof window.showDirectoryPicker === 'function';
}

export async function computeFileSha256(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  return computeSHA256(buffer);
}

export async function registerFilesFromPicker(
  files: File[],
  options: {
    projectId: number | null;
    storageSource: StorageSource;
    baseFolder?: string;
    tags?: string[];
  }
): Promise<{
  registered: DocumentRecord[];
  duplicatesDetected: Array<{ fileName: string; existingTitle: string }>;
}> {
  const journalId = beginOperationJournal(`register_${files.length}_documents`);
  const registered: DocumentRecord[] = [];
  const duplicatesDetected: Array<{ fileName: string; existingTitle: string }> = [];

  try {
    for (const file of files) {
      const sha256Hash = await computeFileSha256(file);
      const relPath =
        (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
        (options.baseFolder ? `${options.baseFolder}/${file.name}` : `/${file.name}`);

      const title = file.name.replace(/\.[^/.]+$/, '') || file.name;
      const res = await registerDocument({
        projectId: options.projectId,
        title,
        fileName: file.name,
        relativePath: relPath,
        mimeType: file.type || 'application/octet-stream',
        sizeBytes: file.size,
        sha256Hash,
        storageSource: options.storageSource,
        uriReference: `saf://${relPath}`,
        tags: options.tags ?? [],
        notes: 'ثبت مستقیم مرجع فایل بدون کپی‌برداری اضافه',
      });

      registered.push(res.document);
      if (res.duplicateOf) {
        duplicatesDetected.push({
          fileName: file.name,
          existingTitle: res.duplicateOf.title,
        });
      }
    }
    completeOperationJournal(journalId);
  } catch (err) {
    throw err;
  }

  return { registered, duplicatesDetected };
}

export async function pickAndRegisterSafDirectory(projectId: number | null): Promise<{
  folderName: string;
  filesCount: number;
  duplicatesCount: number;
}> {
  if (!window.showDirectoryPicker) {
    throw new Error('انتخابگر پوشه مستقیم (SAF) در این مرورگر در دسترس نیست؛ از انتخابگر پوشه جایگزین استفاده کنید.');
  }

  const dirHandle = await window.showDirectoryPicker({ mode: 'read' });
  const collected: File[] = [];

  async function walk(handle: FileSystemDirectoryHandle, prefix: string) {
    for await (const [, entry] of (handle as unknown as AsyncIterable<[string, FileSystemHandle]>)) {
      if (entry.kind === 'file') {
        const file = await (entry as FileSystemFileHandle).getFile();
        Object.defineProperty(file, 'webkitRelativePath', {
          value: `${prefix}/${file.name}`,
          configurable: true,
        });
        collected.push(file);
      } else if (entry.kind === 'directory' && collected.length < 250) {
        await walk(entry as FileSystemDirectoryHandle, `${prefix}/${entry.name}`);
      }
    }
  }

  await walk(dirHandle, dirHandle.name);

  const safEntry: StoredSafFolder = {
    id: `${dirHandle.name}_${Date.now()}`,
    name: dirHandle.name,
    handle: dirHandle,
    addedAt: new Date().toISOString(),
    fileCount: collected.length,
  };
  await saveSafFolderHandle(safEntry);

  const result = await registerFilesFromPicker(collected, {
    projectId,
    storageSource: 'saf_tree',
    baseFolder: dirHandle.name,
    tags: ['SAF', dirHandle.name],
  });

  await logArchiveAction({
    actionType: 'integrity_scan',
    targetRef: dirHandle.name,
    details: `ثبت ${result.registered.length} سند از پوشه SAF بدون کپی اضافی`,
    status: 'verified',
  });

  return {
    folderName: dirHandle.name,
    filesCount: result.registered.length,
    duplicatesCount: result.duplicatesDetected.length,
  };
}

export async function getLinkedSafFolders(): Promise<StoredSafFolder[]> {
  return loadSafFolderHandles();
}

export async function verifyDocumentWithFile(documentId: number, file: File): Promise<{
  matches: boolean;
  computedHash: string;
  expectedHash: string;
}> {
  const doc = listDocuments(true).find((d) => d.id === documentId);
  if (!doc) throw new Error('سند یافت نشد');
  const computedHash = await computeFileSha256(file);
  const matches = computedHash === doc.sha256Hash;
  const now = new Date().toISOString();

  await updateDocument(documentId, {
    integrityStatus: matches ? 'verified' : 'mismatch',
    lastVerifiedAt: now,
  });

  await logArchiveAction({
    actionType: 'integrity_scan',
    targetRef: doc.fileName,
    details: matches
      ? `اصالت SHA-256 سند «${doc.title}» تایید شد`
      : `هشدار عدم تطابق SHA-256 برای سند «${doc.title}»`,
    checksum: computedHash,
    status: matches ? 'verified' : 'interrupted',
  });

  return {
    matches,
    computedHash,
    expectedHash: doc.sha256Hash,
  };
}

export function detectDuplicateDocuments(): DuplicateGroup[] {
  const docs = listDocuments(true);
  const map = new Map<string, DocumentRecord[]>();
  for (const doc of docs) {
    const arr = map.get(doc.sha256Hash) ?? [];
    arr.push(doc);
    map.set(doc.sha256Hash, arr);
  }
  const groups: DuplicateGroup[] = [];
  for (const [sha256Hash, groupDocs] of map.entries()) {
    if (groupDocs.length > 1) {
      const fileSize = groupDocs[0].sizeBytes;
      groups.push({
        sha256Hash,
        fileSize,
        totalWastedBytes: fileSize * (groupDocs.length - 1),
        documents: groupDocs,
      });
    }
  }
  return groups.sort((a, b) => b.totalWastedBytes - a.totalWastedBytes);
}

export function generateSmartArchiveSuggestions(): ArchiveSuggestion[] {
  const autoDays = Number(getSetting('auto_archive_days', '30')) || 30;
  const largeThresholdBytes = (Number(getSetting('large_file_threshold_mb', '10')) || 10) * 1024 * 1024;
  const now = Date.now();

  const suggestions: ArchiveSuggestion[] = [];

  for (const mem of listMemories(false)) {
    if (mem.isPinned) continue;
    const ageDays = Math.floor((now - new Date(mem.updatedAt).getTime()) / 86400_000);
    if (ageDays >= autoDays) {
      suggestions.push({
        id: `mem-${mem.id}`,
        targetType: 'memory',
        targetId: mem.id,
        title: mem.title,
        reason: `حافظه بدون تغییر از ${ageDays} روز قبل (پیشنهاد بایگانی منظم)`,
        ageDays,
        reclaimableBytes: new TextEncoder().encode(mem.content).byteLength,
        priority: ageDays > autoDays * 2 ? 'high' : 'medium',
      });
    }
  }

  const duplicates = detectDuplicateDocuments();
  const duplicateIds = new Set<number>();
  for (const grp of duplicates) {
    grp.documents.slice(1).forEach((d) => duplicateIds.add(d.id));
  }

  for (const doc of listDocuments(false)) {
    const ageDays = Math.floor((now - new Date(doc.updatedAt).getTime()) / 86400_000);
    if (duplicateIds.has(doc.id)) {
      suggestions.push({
        id: `doc-dup-${doc.id}`,
        targetType: 'document',
        targetId: doc.id,
        title: doc.title,
        reason: 'مرجع تکراری با هش SHA-256 یکسان (قابل بایگانی بدون حذف فایل اصلی)',
        ageDays,
        reclaimableBytes: doc.sizeBytes,
        priority: 'high',
      });
    } else if (doc.sizeBytes >= largeThresholdBytes && ageDays >= autoDays) {
      suggestions.push({
        id: `doc-large-${doc.id}`,
        targetType: 'document',
        targetId: doc.id,
        title: doc.title,
        reason: `فایل حجیم و کم‌مصرف (${ageDays} روز بدون تغییر)`,
        ageDays,
        reclaimableBytes: doc.sizeBytes,
        priority: 'medium',
      });
    }
  }

  return suggestions.sort((a, b) => b.reclaimableBytes - a.reclaimableBytes);
}

export async function runSmartArchiveBatch(suggestions: ArchiveSuggestion[]): Promise<number> {
  if (!suggestions.length) return 0;
  const journalId = beginOperationJournal(`smart_archive_batch_${suggestions.length}`);
  let archivedCount = 0;
  try {
    for (const item of suggestions) {
      if (item.targetType === 'memory') {
        await updateMemory(item.targetId, { isArchived: true, changeNote: 'آرشیف خودکار هوشمند' });
        archivedCount++;
      } else {
        await updateDocument(item.targetId, { isArchived: true });
        archivedCount++;
      }
    }
    completeOperationJournal(journalId);
    await logArchiveAction({
      actionType: 'archive_moved',
      targetRef: `${archivedCount} مورد`,
      details: `آرشیف دسته‌ای هوشمند برای ${archivedCount} رکورد انجام شد (فایل‌های شخصی دست‌نخورده ماندند)`,
      status: 'completed',
    });
  } catch (err) {
    throw err;
  }
  return archivedCount;
}

function classifyMime(mime: string, fileName: string): string {
  const lower = `${mime} ${fileName}`.toLowerCase();
  if (lower.includes('pdf') || lower.includes('word') || lower.includes('text') || lower.includes('markdown')) {
    return 'اسناد متنی و PDF';
  }
  if (lower.includes('image') || /\.(png|jpg|jpeg|webp|svg)$/.test(lower)) {
    return 'تصاویر و نمودارها';
  }
  if (lower.includes('video') || lower.includes('audio')) {
    return 'چندرسانه‌ای';
  }
  if (lower.includes('json') || lower.includes('sqlite') || lower.includes('csv') || lower.includes('zip')) {
    return 'داده‌ها و بایگانی‌ها';
  }
  return 'سایر فایل‌ها';
}

export async function generateStorageReport(): Promise<StorageReport> {
  const docs = listDocuments(true);
  const health = getDatabaseHealth();
  const largeThresholdBytes = (Number(getSetting('large_file_threshold_mb', '10')) || 10) * 1024 * 1024;
  const lowThresholdMb = Number(getSetting('low_storage_threshold_mb', '512')) || 512;

  let deviceQuotaBytes = 128 * 1024 * 1024 * 1024; // Fallback if StorageManager unavailable
  let deviceUsageBytes = health.dbSizeBytes;

  if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
    try {
      const est = await navigator.storage.estimate();
      if (est.quota && est.quota > 0) deviceQuotaBytes = est.quota;
      if (est.usage !== undefined) deviceUsageBytes = est.usage;
    } catch {
      // ignore fallback
    }
  }

  // Also inspect Android bridge if available
  if (typeof window !== 'undefined' && window.NovaAndroidBridge?.getDeviceStorageStats) {
    try {
      const parsed = JSON.parse(window.NovaAndroidBridge.getDeviceStorageStats()) as {
        totalBytes?: number;
        usedBytes?: number;
      };
      if (parsed.totalBytes) deviceQuotaBytes = parsed.totalBytes;
      if (parsed.usedBytes !== undefined) deviceUsageBytes = parsed.usedBytes;
    } catch {
      // ignore
    }
  }

  const registeredDocumentsBytes = docs.reduce((sum, d) => sum + d.sizeBytes, 0);
  const archivedBytes = docs.filter((d) => d.isArchived).reduce((sum, d) => sum + d.sizeBytes, 0);
  const largeFilesCount = docs.filter((d) => d.sizeBytes >= largeThresholdBytes).length;
  const duplicateGroups = detectDuplicateDocuments();
  const reclaimableDuplicateBytes = duplicateGroups.reduce((sum, g) => sum + g.totalWastedBytes, 0);

  const deviceAvailableBytes = Math.max(0, deviceQuotaBytes - deviceUsageBytes);
  const lowStorageWarning = deviceAvailableBytes < lowThresholdMb * 1024 * 1024;

  const categoryMap = new Map<string, { bytes: number; count: number }>();
  for (const d of docs) {
    const label = classifyMime(d.mimeType, d.fileName);
    const cur = categoryMap.get(label) ?? { bytes: 0, count: 0 };
    cur.bytes += d.sizeBytes;
    cur.count += 1;
    categoryMap.set(label, cur);
  }

  return {
    deviceQuotaBytes,
    deviceUsageBytes,
    deviceAvailableBytes,
    registeredDocumentsBytes,
    sqliteDbBytes: health.dbSizeBytes,
    archivedBytes,
    largeFilesCount,
    duplicateGroupsCount: duplicateGroups.length,
    reclaimableDuplicateBytes,
    lowStorageWarning,
    lowStorageThresholdMb: lowThresholdMb,
    byMimeCategory: Array.from(categoryMap.entries()).map(([label, val]) => ({
      label,
      bytes: val.bytes,
      count: val.count,
    })),
  };
}
