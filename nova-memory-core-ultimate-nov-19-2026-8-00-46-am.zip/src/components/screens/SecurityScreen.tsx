import React, { useEffect, useState } from 'react';
import { CheckCircle2, Fingerprint, KeyRound, Lock, ShieldCheck } from 'lucide-react';
import { getSetting, listDocuments, logArchiveAction } from '../../db/sqliteEngine';
import { NOVA_PACKAGE_ID } from '../../db/schema';
import { toPersianDigits } from '../../services/androidBridge';
import {
  decryptBytesAESGCM,
  encryptBytesAESGCM,
  enrollBiometricPasskey,
  isBiometricHardwareAvailable,
  setSecurityPin,
} from '../../services/cryptoService';

interface SecurityScreenProps {
  onLockNow: () => void;
  onRefresh: () => Promise<void>;
}

export const SecurityScreen: React.FC<SecurityScreenProps> = ({ onLockNow, onRefresh }) => {
  const [pinInput, setPinInput] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [bioAvailable, setBioAvailable] = useState(false);
  const [cryptoTestMsg, setCryptoTestMsg] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const hasPin = Boolean(getSetting('pin_hash', ''));
  const biometricEnabled = getSetting('biometric_enabled', 'false') === 'true';
  const keystoreAlias = getSetting('keystore_alias', 'nova_master_aes_gcm_v3');
  const docs = listDocuments(true);
  const verifiedDocs = docs.filter((d) => d.integrityStatus === 'verified').length;

  useEffect(() => {
    isBiometricHardwareAvailable().then(setBioAvailable);
  }, []);

  const handleSavePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setFeedback(null);
    if (pinInput.length < 4) {
      setError('پین امنیتی باید حداقل ۴ رقم یا کاراکتر باشد.');
      return;
    }
    if (pinInput !== pinConfirm) {
      setError('تکرار پین امنیتی مطابقت ندارد.');
      return;
    }
    await setSecurityPin(pinInput);
    setPinInput('');
    setPinConfirm('');
    setFeedback('پین امنیتی با هش SHA-256 ذخیره و قفل برنامه فعال شد.');
    await onRefresh();
  };

  const handleDisablePin = async () => {
    await setSecurityPin('');
    setFeedback('قفل پین غیرفعال شد.');
    await onRefresh();
  };

  const handleEnableBiometric = async () => {
    setError(null);
    const res = await enrollBiometricPasskey();
    if (res.ok) {
      setFeedback(res.message);
      await onRefresh();
    } else {
      setError(res.message);
    }
  };

  const handleRunAesSelfTest = async () => {
    setError(null);
    const sample = new TextEncoder().encode(`NOVA_KEYSTORE_VERIFY:${Date.now()}:${NOVA_PACKAGE_ID}`);
    const testPass = 'nova-self-test-key';
    const encrypted = await encryptBytesAESGCM(sample, testPass);
    const decrypted = await decryptBytesAESGCM(encrypted, testPass);
    const ok = new TextDecoder().decode(decrypted) === new TextDecoder().decode(sample);

    await logArchiveAction({
      actionType: 'integrity_scan',
      targetRef: 'AES-256-GCM Self-Test',
      details: ok
        ? `آزمایش رمزنگاری AES-256-GCM و تطابق SHA-256 موفق بود`
        : 'خطا در آزمایش رمزنگاری',
      checksum: encrypted.plaintextSha256,
      status: ok ? 'verified' : 'interrupted',
    });

    setCryptoTestMsg(
      ok
        ? `تایید موفق AES-256-GCM · IV: ${encrypted.ivBase64.slice(0, 12)}… · SHA-256: ${encrypted.plaintextSha256.slice(0, 16)}…`
        : 'آزمایش رمزنگاری ناموفق بود.'
    );
    await onRefresh();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-100">مرکز امنیت، بایومتریک و رمزنگاری</h1>
        <p className="text-xs text-slate-400 mt-1">
          مدیریت قفل برنامه، احراز هویت بایومتریک، سازگاری Android Keystore / AES-256-GCM و حفظ هویت بسته
        </p>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3.5 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}
      {error && (
        <div className="rounded-xl border border-rose-500/35 bg-rose-500/10 p-3.5 text-xs text-rose-200">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* PIN & App Lock */}
        <form onSubmit={handleSavePin} className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-amber-400" />
              <span>قفل امنیتی و پین آفلاین</span>
            </h2>
            <span className={`text-xs ${hasPin ? 'text-emerald-400' : 'text-slate-400'}`}>
              {hasPin ? 'فعال' : 'تنظیم‌نشده'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="password"
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder="پین جدید (حداقل ۴ کاراکتر)"
              className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
            />
            <input
              type="password"
              value={pinConfirm}
              onChange={(e) => setPinConfirm(e.target.value)}
              placeholder="تکرار پین جدید"
              className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              className="min-h-[44px] rounded-xl bg-emerald-600 px-4 text-sm font-semibold text-white hover:bg-emerald-500"
            >
              ذخیره پین امنیتی
            </button>
            {hasPin && (
              <>
                <button
                  type="button"
                  onClick={onLockNow}
                  className="min-h-[44px] inline-flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 text-sm font-medium text-amber-300 hover:bg-amber-500/20"
                >
                  <Lock className="h-4 w-4" />
                  <span>قفل فوری برنامه</span>
                </button>
                <button
                  type="button"
                  onClick={handleDisablePin}
                  className="min-h-[44px] rounded-xl border border-slate-700 px-3 text-xs text-slate-300 hover:bg-slate-800"
                >
                  حذف قفل پین
                </button>
              </>
            )}
          </div>
        </form>

        {/* Biometric & Keystore */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Fingerprint className="h-4 w-4 text-emerald-400" />
              <span>احراز هویت بایومتریک و Keystore</span>
            </h2>
            <span className={`text-xs ${biometricEnabled ? 'text-emerald-400' : 'text-slate-400'}`}>
              {biometricEnabled ? 'فعال' : 'آماده فعال‌سازی'}
            </span>
          </div>

          <div className="text-xs text-slate-300 space-y-1.5">
            <div>
              سخت‌افزار بایومتریک مرورگر/دستگاه:{' '}
              <span className="text-emerald-300">{bioAvailable ? 'پشتیبانی می‌شود' : 'پشتیبانی در Android BiometricPrompt'}</span>
            </div>
            <div>
              کلیدگاه: <span className="font-mono-tabular text-amber-300">{keystoreAlias}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={handleEnableBiometric}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 text-sm font-medium text-emerald-300 hover:bg-emerald-500/20"
            >
              <Fingerprint className="h-4 w-4" />
              <span>فعال‌سازی بایومتریک</span>
            </button>

            <button
              type="button"
              onClick={handleRunAesSelfTest}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-[#132540] px-4 text-sm font-medium text-slate-200 hover:border-amber-500/40"
            >
              <ShieldCheck className="h-4 w-4 text-amber-400" />
              <span>آزمایش زنده AES-256-GCM</span>
            </button>
          </div>

          {cryptoTestMsg && (
            <div className="rounded-xl bg-[#07101f] border border-emerald-500/30 p-3 text-xs font-mono-tabular text-emerald-300 break-all" dir="ltr">
              {cryptoTestMsg}
            </div>
          )}
        </div>
      </div>

      {/* Signing Compatibility & Zero-Key-Exposure Audit */}
      <section className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-3">
        <h2 className="text-base font-bold text-slate-100">هویت امضای اندروید و وضعیت یکپارچگی</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3.5">
            <div className="text-slate-400">شناسه بسته حفظ‌شده (Package ID)</div>
            <div className="mt-1 font-mono-tabular text-amber-300" dir="ltr">
              {NOVA_PACKAGE_ID}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3.5">
            <div className="text-slate-400">اسناد تاییدشده SHA-256</div>
            <div className="mt-1 font-semibold tabular-nums text-emerald-300">
              {toPersianDigits(verifiedDocs)} از {toPersianDigits(docs.length)} سند
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3.5">
            <div className="text-slate-400">سیاست نگهداری کلیدها</div>
            <div className="mt-1 text-slate-200">عدم افشای کلید خصوصی یا رمز خام در رابط و دیتابیس</div>
          </div>
        </div>
      </section>
    </div>
  );
};
