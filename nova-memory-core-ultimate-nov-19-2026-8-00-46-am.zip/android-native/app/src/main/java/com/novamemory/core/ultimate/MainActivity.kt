package com.novamemory.core.ultimate

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebViewAssetLoader
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class NovaDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "nova_memory_core.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        onUpgrade(db, 0, 3)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.beginTransaction()
        try {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'عمومی',
                    tags TEXT NOT NULL DEFAULT '[]',
                    importance TEXT NOT NULL DEFAULT 'عادی',
                    language TEXT NOT NULL DEFAULT 'fa-AF',
                    is_pinned INTEGER NOT NULL DEFAULT 0,
                    is_archived INTEGER NOT NULL DEFAULT 0,
                    checksum TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """.trimIndent())
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    project_type TEXT NOT NULL DEFAULT 'research',
                    status TEXT NOT NULL DEFAULT 'active',
                    progress INTEGER NOT NULL DEFAULT 0,
                    tags TEXT NOT NULL DEFAULT '[]',
                    folder_path TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """.trimIndent())
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id INTEGER NULL,
                    title TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    relative_path TEXT NOT NULL DEFAULT '',
                    mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
                    size_bytes INTEGER NOT NULL DEFAULT 0,
                    sha256_hash TEXT NOT NULL,
                    storage_source TEXT NOT NULL DEFAULT 'saf_tree',
                    uri_reference TEXT NOT NULL DEFAULT '',
                    integrity_status TEXT NOT NULL DEFAULT 'verified',
                    last_verified_at TEXT NULL,
                    is_archived INTEGER NOT NULL DEFAULT 0,
                    tags TEXT NOT NULL DEFAULT '[]',
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """.trimIndent())
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}

object NovaKeystoreCrypto {
    private const val ALIAS = "nova_master_aes_gcm_v3"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        keyGen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return keyGen.generateKey()
    }

    fun encrypt(bytes: ByteArray): Pair<ByteArray, ByteArray> {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        return Pair(cipher.iv, cipher.doFinal(bytes))
    }

    fun decrypt(iv: ByteArray, ciphertext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }
}

class NovaArchiveWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // Periodic integrity & archive maintenance without deleting personal files
        val dbHelper = NovaDatabaseHelper(applicationContext)
        dbHelper.readableDatabase.use { db ->
            db.rawQuery("PRAGMA integrity_check;", null).use { cursor ->
                if (cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                    return Result.success()
                }
            }
        }
        return Result.retry()
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    private val safTreeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        treeUri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            treeUri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        val rootDoc = DocumentFile.fromTreeUri(this, treeUri)
        val list = JSONArray()
        rootDoc?.listFiles()?.take(200)?.forEach { doc ->
            if (doc.isFile) {
                val sha = computeUriSha256(doc.uri)
                list.put(JSONObject().apply {
                    put("name", doc.name ?: "document")
                    put("size", doc.length())
                    put("mime", doc.type ?: "application/octet-stream")
                    put("uri", doc.uri.toString())
                    put("sha256", sha)
                })
            }
        }
        webView.post {
            webView.evaluateJavascript("window.onNovaSafFilesSelected && window.onNovaSafFilesSelected(${list});", null)
        }
    }

    private fun computeUriSha256(uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(uri)?.use { stream ->
            val buf = ByteArray(8192)
            var read: Int
            while (stream.read(buf).also { read = it } != -1) {
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false

        webView.webViewClient = object : androidx.webkit.WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.addJavascriptInterface(NovaJsBridge(), "NovaAndroidBridge")
        webView.loadUrl("https://appassets.androidplatform.net/assets/dist/index.html")
    }

    inner class NovaJsBridge {
        @JavascriptInterface
        fun pickSafDirectory() {
            runOnUiThread { safTreeLauncher.launch(null) }
        }

        @JavascriptInterface
        fun getDeviceStorageStats(): String {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.blockCountLong * stat.blockSizeLong
            val available = stat.availableBlocksLong * stat.blockSizeLong
            return JSONObject().apply {
                put("totalBytes", total)
                put("usedBytes", total - available)
                put("availableBytes", available)
            }.toString()
        }

        @JavascriptInterface
        fun authenticateBiometric(): Boolean {
            val manager = BiometricManager.from(this@MainActivity)
            if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) {
                return false
            }
            runOnUiThread {
                val executor = ContextCompat.getMainExecutor(this@MainActivity)
                val prompt = BiometricPrompt(
                    this@MainActivity,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {}
                )
                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("NOVA MEMORY CORE ULTIMATE")
                    .setSubtitle("تایید هویت بایومتریک")
                    .setNegativeButtonText("لغو")
                    .build()
                prompt.authenticate(info)
            }
            return true
        }

        @JavascriptInterface
        fun scheduleArchiveWorker(days: Int): Boolean {
            val req = PeriodicWorkRequestBuilder<NovaArchiveWorker>(1, TimeUnit.DAYS).build()
            WorkManager.getInstance(this@MainActivity).enqueueUniquePeriodicWork(
                "nova_smart_archive",
                ExistingPeriodicWorkPolicy.KEEP,
                req
            )
            return true
        }
    }
}
