# راهنمای کامل ساخت و امضای APK در Termux (Samsung Galaxy A52 — Android 14)

## ۱. پیش‌نیازها در Termux
```bash
pkg update && pkg upgrade -y
pkg install -y nodejs-lts openjdk-17 gradle wget unzip
```

## ۲. ساخت نسخه وب (PWA + SQLite WASM)
```bash
npm install
npm run build
```

## ۳. همگام‌سازی دارایی‌های وب با پروژه نیتیو اندروید
```bash
mkdir -p android-native/app/src/main/assets/dist
cp -r dist/* android-native/app/src/main/assets/dist/
```

## ۴. کامپایل APK با حفظ شناسه بسته اصلی (`com.novamemory.core.ultimate`)
```bash
cd android-native
gradle assembleRelease
```

## ۵. امضای APK با کلید اصلی قبلی برای حفظ سازگاری بروزرسانی
> **مهم:** برای اینکه بروزرسانی روی نسخه نصب‌شده فعلی گوشی بدون خطای امضا و بدون پاک شدن دیتابیس نصب شود، حتماً از همان Keystore امضای قبلی خود استفاده کنید.

```bash
apksigner sign \
  --ks /path/to/your-existing-release.keystore \
  --ks-key-alias your_existing_alias \
  --out nova-memory-core-v3-signed.apk \
  app/build/outputs/apk/release/app-release-unsigned.apk

apksigner verify --verbose nova-memory-core-v3-signed.apk
```
