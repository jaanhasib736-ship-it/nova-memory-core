import React, { useState } from 'react';
import {
  Archive,
  BookOpen,
  BrainCircuit,
  FolderKanban,
  HardDrive,
  Home,
  Menu,
  Search,
  Settings,
  ShieldCheck,
  WifiOff,
  X,
} from 'lucide-react';
import type { ScreenId } from '../../types/nova';
import { useOnlineStatus } from '../../hooks/usePWAInstall';

export interface NavItem {
  id: ScreenId;
  label: string;
  shortLabel: string;
  icon: React.FC<{ className?: string }>;
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'خانه', shortLabel: 'خانه', icon: Home },
  { id: 'memories', label: 'حافظه هوشمند', shortLabel: 'حافظه', icon: BrainCircuit },
  { id: 'projects', label: 'مدیریت پروژه‌ها', shortLabel: 'پروژه‌ها', icon: FolderKanban },
  { id: 'documents', label: 'کتابخانه اسناد', shortLabel: 'اسناد', icon: BookOpen },
  { id: 'storage', label: 'مدیریت حافظه موبایل', shortLabel: 'حافظه موبایل', icon: HardDrive },
  { id: 'archive', label: 'آرشیف هوشمند', shortLabel: 'آرشیف', icon: Archive },
  { id: 'search', label: 'جستوجوی یکپارچه', shortLabel: 'جستوجو', icon: Search },
  { id: 'security', label: 'امنیت', shortLabel: 'امنیت', icon: ShieldCheck },
  { id: 'settings', label: 'تنظیمات', shortLabel: 'تنظیمات', icon: Settings },
];

interface AppShellProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  onQuickSearchOpen: () => void;
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({
  activeScreen,
  onNavigate,
  onQuickSearchOpen,
  children,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const isOnline = useOnlineStatus();
  const activeItem = NAV_ITEMS.find((n) => n.id === activeScreen) ?? NAV_ITEMS[0];

  const primaryBottomItems: NavItem[] = [
    NAV_ITEMS[0], // خانه
    NAV_ITEMS[1], // حافظه
    NAV_ITEMS[3], // اسناد
    NAV_ITEMS[6], // جستوجو
  ];

  const handleSelect = (id: ScreenId) => {
    onNavigate(id);
    setDrawerOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#07101f] text-slate-100 flex flex-col lg:flex-row">
      {/* Desktop RTL Right Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:shrink-0 lg:flex-col border-l border-slate-800/80 bg-[#0a1528]">
        <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-800/80">
          <img
            src="/icon.svg"
            alt="NOVA MEMORY CORE ULTIMATE"
            className="h-9 w-9 rounded-xl shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0">
            <div className="text-sm font-bold tracking-tight text-slate-100 truncate">
              NOVA MEMORY CORE
            </div>
            <div className="text-xs text-amber-400/90 truncate">نسخه یکپارچه V3.0</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="ناوبری اصلی">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeScreen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelect(item.id)}
                className={`w-full min-h-[44px] flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-slate-100 border border-transparent'
                }`}
              >
                <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800/80 text-xs text-slate-400 space-y-1">
          <div className="text-slate-300 font-medium truncate">حسیب‌الرحمن صاحب‌زاده</div>
          <div className="truncate">Galaxy A52 · Android 14</div>
        </div>
      </aside>

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Clean 3-Zone Top Bar (Compact 52px-56px on Mobile) */}
        <header className="sticky top-0 z-30 h-14 border-b border-slate-800/80 bg-[#07101f]/90 backdrop-blur-md px-4 lg:px-8 flex items-center justify-between gap-4">
          {/* Zone 1: Brand Title */}
          <button
            type="button"
            onClick={() => handleSelect('home')}
            className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0 flex items-center gap-2.5"
          >
            <span className="lg:hidden inline-block h-6 w-6 rounded-lg overflow-hidden shrink-0">
              <img src="/icon.svg" alt="نوا" className="h-full w-full" referrerPolicy="no-referrer" />
            </span>
            <span>هسته حافظه نووا</span>
          </button>

          {/* Zone 2: Active Context Label */}
          <div className="hidden sm:flex items-center gap-2 text-sm text-slate-300 truncate">
            <span className="text-slate-500">/</span>
            <span className="font-medium text-emerald-300 truncate">{activeItem.label}</span>
            {!isOnline && (
              <>
                <span className="text-slate-600">·</span>
                <span className="inline-flex items-center gap-1 text-xs text-amber-300">
                  <WifiOff className="h-3.5 w-3.5" />
                  حالت آفلاین
                </span>
              </>
            )}
          </div>

          {/* Zone 3: Single Primary Action (Unified Search Trigger) */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onQuickSearchOpen}
              className="min-h-[40px] inline-flex items-center gap-2 rounded-xl border border-amber-500/35 bg-amber-500/10 px-3.5 py-1.5 text-xs sm:text-sm font-medium text-amber-300 hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0"
            >
              <Search className="h-4 w-4" />
              <span>جستوجوی یکپارچه</span>
            </button>
          </div>
        </header>

        {/* Scrollable Content Viewport */}
        <main className="flex-1 px-4 py-5 pb-24 lg:px-8 lg:py-7 lg:pb-10 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Mobile Fixed Bottom Thumb Navigation (Height <= 60px, fits 15% sticky budget) */}
      <nav
        aria-label="ناوبری سریع موبایل"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-15 pb-safe border-t border-slate-800/90 bg-[#0a1528]/95 backdrop-blur-md grid grid-cols-5 items-center"
      >
        {primaryBottomItems.map((item) => {
          const Icon = item.icon;
          const active = activeScreen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              className={`h-full min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
                active ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="truncate max-w-[68px]">{item.shortLabel}</span>
            </button>
          );
        })}

        <button
          type="button"
          onClick={() => setDrawerOpen(true)}
          className={`h-full min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
            drawerOpen || !primaryBottomItems.some((i) => i.id === activeScreen)
              ? 'text-amber-300'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Menu className="h-5 w-5" />
          <span>بخش‌ها</span>
        </button>
      </nav>

      {/* Mobile Bottom Sheet Drawer for All 9 Screens */}
      {drawerOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end"
          onClick={() => setDrawerOpen(false)}
        >
          <div
            className="w-full rounded-t-3xl border-t border-slate-700/80 bg-[#0d1b30] px-4 pt-3 pb-6 max-h-[82vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mb-3" />
            <div className="flex items-center justify-between px-2 pb-3 border-b border-slate-800">
              <span className="text-sm font-bold text-slate-100">همه بخش‌های نوا</span>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-100"
                aria-label="بستن فهرست"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2.5">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeScreen === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`min-h-[52px] flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl text-right text-sm font-medium border transition-colors ${
                      active
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                        : 'bg-[#132540]/70 border-slate-800 text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-emerald-400' : 'text-amber-400/80'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
