import React, { useState } from 'react';
import { Lock, ShieldCheck } from 'lucide-react';
import { verifySecurityPin } from '../../services/cryptoService';

interface LockScreenModalProps {
  onUnlock: () => void;
}

export const LockScreenModal: React.FC<LockScreenModalProps> = ({ onUnlock }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await verifySecurityPin(pin);
    if (ok) {
      setError(null);
      setPin('');
      onUnlock();
    } else {
      setError('پین امنیتی نادرست است.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#07101f]/98 backdrop-blur-md flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-3xl border border-slate-800 bg-[#0d1b30] p-7 space-y-5 text-center shadow-2xl"
      >
        <div className="mx-auto h-14 w-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
          <Lock className="h-7 w-7 text-emerald-400" />
        </div>

        <div>
          <h2 className="text-lg font-bold text-slate-100">NOVA MEMORY CORE ULTIMATE</h2>
          <p className="text-xs text-slate-400 mt-1">برای باز کردن قفل حافظه، پین امنیتی خود را وارد کنید</p>
        </div>

        <input
          type="password"
          autoFocus
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          placeholder="پین امنیتی..."
          className="w-full min-h-[48px] rounded-xl border border-slate-700 bg-[#07101f] px-4 text-center text-base tracking-widest text-slate-100 focus:border-emerald-500 focus:outline-none"
        />

        {error && <div className="text-xs text-rose-400">{error}</div>}

        <button
          type="submit"
          className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500"
        >
          <ShieldCheck className="h-4 w-4" />
          <span>باز کردن قفل سامانه</span>
        </button>
      </form>
    </div>
  );
};
