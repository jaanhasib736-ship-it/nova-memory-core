import React, { useState } from 'react';
import { Download, Smartphone, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return (
      <div className="inline-flex items-center gap-2 text-xs text-emerald-400">
        <CheckCircle2 className="h-4 w-4" />
        <span>نصب‌شده به صورت اپلیکیشن مستقل</span>
      </div>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap shrink-0"
      >
        <Download className="h-4 w-4" />
        <span>نصب آفلاین روی موبایل</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-sm font-medium text-amber-300 transition-colors hover:bg-amber-500/20 whitespace-nowrap shrink-0"
        >
          <Smartphone className="h-4 w-4" />
          <span>نصب در آیفون / آیپد</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
            <div className="w-full max-w-sm rounded-2xl border border-slate-700 bg-[#0d1b30] p-6 shadow-2xl">
              <h3 className="text-base font-bold text-slate-100">نصب آفلاین در سافاری</h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                ۱. دکمه Share را در نوار مرورگر بزنید.
                <br />
                ۲. گزینه Add to Home Screen را انتخاب کنید.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-xl bg-emerald-600 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
              >
                بستن
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <span className="text-xs text-slate-400">
      برای نصب آفلاین در Galaxy A52، از منوی مرورگر Chrome گزینه «Install App» یا بیلد APK را استفاده کنید.
    </span>
  );
};
