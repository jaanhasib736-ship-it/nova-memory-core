import React, { useState } from 'react';
import {
  AlertTriangle,
  Archive,
  ArrowUpLeft,
  BookOpen,
  BrainCircuit,
  FolderKanban,
  HardDrive,
  Plus,
  Search,
  ShieldCheck,
} from 'lucide-react';
import {
  autoCategorizeMemory,
  createMemory,
  listArchiveLogs,
  listDocuments,
  listMemories,
  listProjects,
} from '../../db/sqliteEngine';
import { formatBytesDari, formatDateDari, toPersianDigits } from '../../services/androidBridge';
import type { ArchiveSuggestion, DatabaseHealth, NavigationIntent, StorageReport } from '../../types/nova';

interface HomeScreenProps {
  health: DatabaseHealth;
  storageReport: StorageReport;
  suggestions: ArchiveSuggestion[];
  onRefresh: () => Promise<void>;
  onNavigateIntent: (intent: NavigationIntent) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  health,
  storageReport,
  suggestions,
  onRefresh,
  onNavigateIntent,
}) => {
  const [quickTitle, setQuickTitle] = useState('');
  const [quickContent, setQuickContent] = useState('');
  const [savingQuick, setSavingQuick] = useState(false);
  const [quickFeedback, setQuickFeedback] = useState<string | null>(null);

  const memories = listMemories(false);
  const projects = listProjects();
  const documents = listDocuments(false);
  const recentLogs = listArchiveLogs(5);

  const usedPercent = Math.min(
    100,
    Math.round((storageReport.deviceUsageBytes / Math.max(1, storageReport.deviceQuotaBytes)) * 100)
  );
  const ringCircumference = 2 * Math.PI * 38;
  const ringDashOffset = ringCircumference * (1 - usedPercent / 100);

  const handleQuickSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim() && !quickContent.trim()) return;
    setSavingQuick(true);
    try {
      const title = quickTitle.trim() || quickContent.trim().slice(0, 42);
      const content = quickContent.trim() || quickTitle.trim();
      const category = autoCategorizeMemory(title, content);
      await createMemory({ title, content, category, importance: 'عادی', tags: [category] });
      setQuickTitle('');
      setQuickContent('');
      setQuickFeedback(`با دسته‌بندی خودکار «${category}» در SQLite ذخیره شد.`);
      await onRefresh();
    } finally {
      setSavingQuick(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Low Storage or Recovery Alert */}
      {storageReport.lowStorageWarning && (
        <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1 text-sm">
            <div className="font-semibold text-amber-200">هشدار کمبود فضای آزاد حافظه</div>
            <p className="mt-1 text-amber-100/80">
              فضای آزاد دستگاه کمتر از حد آستانه ({toPersianDigits(storageReport.lowStorageThresholdMb)} مگابایت) است.
              پیشنهاد می‌شود بخش مدیریت حافظه موبایل را بررسی کنید.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigateIntent({ screen: 'storage' })}
            className="min-h-[40px] rounded-xl bg-amber-500/20 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/30 whitespace-nowrap"
          >
            بررسی حافظه
          </button>
        </div>
      )}

      {health.recoveredOperations > 0 && (
        <div className="rounded-2xl border border-emerald-500/35 bg-emerald-500/10 p-4 text-sm text-emerald-200 flex items-center justify-between gap-3">
          <span>
            {toPersianDigits(health.recoveredOperations)} عملیات ناتمام پس از راه‌اندازی مجدد به صورت ایمن بازیابی شد.
          </span>
          <button
            type="button"
            onClick={() => onNavigateIntent({ screen: 'archive' })}
            className="text-xs font-semibold underline underline-offset-4 text-emerald-300 whitespace-nowrap"
          >
            مشاهده گزارش
          </button>
        </div>
      )}

      {/* Hero Split: Command Identity + Storage Ring */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <div className="lg:col-span-8 rounded-2xl border border-slate-800 bg-[#0d1b30] p-6 flex flex-col justify-between">
          <div>
            <div className="text-xs text-amber-400/90 font-medium">
              حسیب‌الرحمن صاحب‌زاده · Samsung Galaxy A52 · Android 14
            </div>
            <h1 className="mt-2 text-2xl sm:text-3xl font-bold text-slate-50 leading-snug">
              NOVA MEMORY CORE ULTIMATE
            </h1>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed max-w-2xl">
              مرکز یکپارچه مدیریت حافظه‌های هوشمند، پروژه‌ها، کتابخانه اسناد با اصالت‌سنجی SHA-256،
              آرشیف خودکار و امنیت رمزنگاری‌شده آفلاین در یک پایگاه‌داده واحد SQLite.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigateIntent({ screen: 'search' })}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              <Search className="h-4 w-4" />
              <span>جستوجوی یکپارچه در ۳ ماژول</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateIntent({ screen: 'documents' })}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-[#132540] px-4 py-2.5 text-sm font-medium text-slate-200 hover:border-emerald-500/40 transition-colors"
            >
              <BookOpen className="h-4 w-4 text-amber-400" />
              <span>ثبت سند با SAF</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateIntent({ screen: 'archive' })}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-[#132540] px-4 py-2.5 text-sm font-medium text-slate-200 hover:border-amber-500/40 transition-colors"
            >
              <Archive className="h-4 w-4 text-emerald-400" />
              <span>پشتیبان‌گیری رمزنگاری‌شده</span>
            </button>
          </div>
        </div>

        {/* Storage Gauge Card */}
        <div className="lg:col-span-4 rounded-2xl border border-slate-800 bg-[#0d1b30] p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-200">وضعیت حافظه و پایگاه‌داده</span>
            <HardDrive className="h-4 w-4 text-emerald-400" />
          </div>

          <div className="my-4 flex items-center gap-5">
            <div className="relative h-24 w-24 shrink-0">
              <svg viewBox="0 0 96 96" className="h-full w-full -rotate-90">
                <circle cx="48" cy="48" r="38" stroke="#1b3152" strokeWidth="8" fill="none" />
                <circle
                  cx="48"
                  cy="48"
                  r="38"
                  stroke={storageReport.lowStorageWarning ? '#f59e0b' : '#10b981'}
                  strokeWidth="8"
                  strokeLinecap="round"
                  fill="none"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringDashOffset}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold tabular-nums text-slate-100">
                  {toPersianDigits(usedPercent)}٪
                </span>
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="text-slate-400">
                آزاد: <span className="text-emerald-300 font-semibold tabular-nums">{formatBytesDari(storageReport.deviceAvailableBytes)}</span>
              </div>
              <div className="text-slate-400">
                اسناد ثبت‌شده: <span className="text-slate-200 font-semibold tabular-nums">{formatBytesDari(storageReport.registeredDocumentsBytes)}</span>
              </div>
              <div className="text-slate-400">
                حجم SQLite: <span className="text-amber-300 font-semibold tabular-nums">{formatBytesDari(storageReport.sqliteDbBytes)}</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateIntent({ screen: 'storage' })}
            className="min-h-[40px] w-full rounded-xl border border-slate-700/80 bg-[#132540]/80 px-3 py-2 text-xs font-medium text-slate-200 hover:border-emerald-500/40 flex items-center justify-between"
          >
            <span>گزارش کامل حافظه موبایل</span>
            <ArrowUpLeft className="h-4 w-4 text-emerald-400" />
          </button>
        </div>
      </section>

      {/* 4-Column Tabular KPI Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => onNavigateIntent({ screen: 'memories' })}
          className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 text-right hover:border-emerald-500/40 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>حافظه‌های فعال</span>
            <BrainCircuit className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {toPersianDigits(memories.length)}
          </div>
          <div className="mt-1 text-xs text-slate-400">
            {toPersianDigits(health.counts.memoryHistory)} سابقه ویرایش
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigateIntent({ screen: 'projects' })}
          className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 text-right hover:border-emerald-500/40 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>پروژه‌ها و کتاب‌ها</span>
            <FolderKanban className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {toPersianDigits(projects.length)}
          </div>
          <div className="mt-1 text-xs text-slate-400">
            {toPersianDigits(projects.filter((p) => p.status === 'active').length)} پروژه فعال
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigateIntent({ screen: 'documents' })}
          className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 text-right hover:border-emerald-500/40 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>اسناد تاییدشده</span>
            <BookOpen className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {toPersianDigits(documents.length)}
          </div>
          <div className="mt-1 text-xs text-slate-400">
            {toPersianDigits(storageReport.duplicateGroupsCount)} گروه تکراری SHA-256
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigateIntent({ screen: 'archive' })}
          className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 text-right hover:border-amber-500/40 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>پیشنهاد آرشیف</span>
            <Archive className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-slate-100">
            {toPersianDigits(suggestions.length)}
          </div>
          <div className="mt-1 text-xs text-slate-400">
            {health.integrityOk ? 'سلامت SQLite تایید شده' : 'نیاز به بررسی'}
          </div>
        </button>
      </section>

      {/* Quick Memory Capture + Recent Activity */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <form
          onSubmit={handleQuickSave}
          className="lg:col-span-6 rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100">ثبت سریع حافظه هوشمند</h2>
            <span className="text-xs text-slate-400">دسته‌بندی خودکار</span>
          </div>

          <input
            type="text"
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder="عنوان کوتاه حافظه یا یادداشت..."
            className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />

          <textarea
            rows={3}
            value={quickContent}
            onChange={(e) => setQuickContent(e.target.value)}
            placeholder="متن حافظه، ایده یا نکته پژوهشی خود را به دری، فارسی یا انگلیسی بنویسید..."
            className="w-full rounded-xl border border-slate-700 bg-[#07101f] px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />

          <div className="flex items-center justify-between gap-3">
            <button
              type="submit"
              disabled={savingQuick || (!quickTitle.trim() && !quickContent.trim())}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              <Plus className="h-4 w-4" />
              <span>{savingQuick ? 'در حال ذخیره...' : 'ذخیره در پایگاه‌داده'}</span>
            </button>
            {quickFeedback && <span className="text-xs text-emerald-300">{quickFeedback}</span>}
          </div>
        </form>

        <div className="lg:col-span-6 rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-bold text-slate-100">آخرین رویدادهای هسته نووا</h2>
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
            </div>

            {recentLogs.length === 0 ? (
              <p className="text-sm text-slate-400 py-6">هنوز رویدادی ثبت نشده است.</p>
            ) : (
              <div className="divide-y divide-slate-800/80">
                {recentLogs.map((log) => (
                  <div key={log.id} className="py-3 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-100 truncate">{log.targetRef}</div>
                      <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{log.details}</div>
                    </div>
                    <span className="text-[11px] text-slate-500 whitespace-nowrap shrink-0 tabular-nums">
                      {formatDateDari(log.createdAt)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>نسخه اسکیما: {toPersianDigits(health.schemaVersion)}</span>
            <span className="font-mono-tabular text-slate-400">{health.packageId}</span>
          </div>
        </div>
      </section>
    </div>
  );
};
