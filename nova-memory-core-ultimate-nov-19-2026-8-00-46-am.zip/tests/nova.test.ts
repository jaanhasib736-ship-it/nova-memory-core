import { describe, expect, it, beforeEach } from 'vitest';
import initSqlJs from 'sql.js';
import {
  autoCategorizeMemory,
  createMemory,
  createProject,
  exportDatabaseBytes,
  getDatabaseHealth,
  getMemoryHistory,
  importDatabaseBytesSafely,
  listDocuments,
  listMemories,
  listProjects,
  registerDocument,
  resetOrMountDatabaseForTesting,
  runDatabaseMaintenance,
  updateMemory,
} from '../src/db/sqliteEngine';
import {
  computeSHA256,
  decryptBytesAESGCM,
  encryptBytesAESGCM,
} from '../src/services/cryptoService';
import { executeUnifiedSearch, normalizeDariText } from '../src/services/searchService';
import {
  detectDuplicateDocuments,
  generateSmartArchiveSuggestions,
  runSmartArchiveBatch,
} from '../src/services/storageService';

describe('NOVA MEMORY CORE ULTIMATE — Integrated 3-Module Verification', () => {
  beforeEach(async () => {
    await resetOrMountDatabaseForTesting();
  });

  it('preserves existing v1 user records during safe schema migration to v3', async () => {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });
    const legacyDb = new SQL.Database();
    legacyDb.run(`
      CREATE TABLE memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL,
        tags TEXT NOT NULL,
        importance TEXT NOT NULL,
        is_pinned INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      INSERT INTO memories (title, content, category, tags, importance, is_pinned, created_at, updated_at)
      VALUES ('یادداشت قدیمی کاربر', 'اطلاعات مهم قبلی که نباید حذف شود', 'شخصی', '["قدیمی"]', 'حیاتی', 1, '2025-01-01T00:00:00.000Z', '2025-01-01T00:00:00.000Z');
      PRAGMA user_version = 1;
    `);
    const legacyBytes = legacyDb.export();
    legacyDb.close();

    await resetOrMountDatabaseForTesting(legacyBytes);
    const health = getDatabaseHealth();
    const memories = listMemories(true);

    expect(health.schemaVersion).toBe(3);
    expect(health.integrityOk).toBe(true);
    expect(memories.length).toBe(1);
    expect(memories[0].title).toBe('یادداشت قدیمی کاربر');
    expect(memories[0].isArchived).toBe(false);
  });

  it('Module 1: supports smart categorization, saving, editing, and immutable edit history', async () => {
    const detected = autoCategorizeMemory('پژوهش تازه', 'مقاله علمی درباره الگوریتم جستجو');
    expect(detected).toBe('پژوهش');

    const created = await createMemory({
      title: 'نکته کلیدی پژوهش دری',
      content: 'متن اولیه یادداشت پژوهشی',
      tags: ['دری', 'پژوهش'],
      importance: 'مهم',
    });

    await updateMemory(created.id, {
      content: 'متن ویرایش‌شده با جزئیات جدید',
      changeNote: 'افزودن جزئیات',
    });

    const history = getMemoryHistory(created.id);
    expect(history.length).toBe(1);
    expect(history[0].previousContent).toBe('متن اولیه یادداشت پژوهشی');
    expect(history[0].changeNote).toBe('افزودن جزئیات');
  });

  it('Module 2: manages projects, document registration, SHA-256 integrity, and duplicate detection', async () => {
    const project = await createProject({
      title: 'پروژه کتابخانه دیجیتال',
      description: 'مدیریت اسناد پژوهشی',
      projectType: 'book',
      progress: 45,
      tags: ['کتاب', 'اسناد'],
    });

    const sampleBytes = new TextEncoder().encode('NOVA DOCUMENT PAYLOAD 2026');
    const hash = await computeSHA256(sampleBytes);

    const reg1 = await registerDocument({
      projectId: project.id,
      title: 'سند اول',
      fileName: 'doc1.txt',
      relativePath: '/Documents/doc1.txt',
      mimeType: 'text/plain',
      sizeBytes: sampleBytes.byteLength,
      sha256Hash: hash,
      storageSource: 'saf_tree',
      uriReference: 'saf://doc1.txt',
      tags: ['کتاب'],
    });

    const reg2 = await registerDocument({
      projectId: project.id,
      title: 'کپی سند اول',
      fileName: 'doc1_copy.txt',
      relativePath: '/Downloads/doc1_copy.txt',
      mimeType: 'text/plain',
      sizeBytes: sampleBytes.byteLength,
      sha256Hash: hash,
      storageSource: 'file_picker',
      uriReference: 'saf://doc1_copy.txt',
    });

    expect(reg1.duplicateOf).toBeNull();
    expect(reg2.duplicateOf?.id).toBe(reg1.document.id);

    const dups = detectDuplicateDocuments();
    expect(dups.length).toBe(1);
    expect(dups[0].documents.length).toBe(2);
    expect(listProjects()[0].documentCount).toBe(2);
  });

  it('Unified Search (جستوجوی یکپارچه): searches across all 3 modules with Dari normalization and fuzzy matching', async () => {
    await createMemory({
      title: 'فهرست کتاب‌های کابل',
      content: 'یادداشت ویژه درباره نسخه‌های خطی دری',
      tags: ['کابل', 'خطی'],
    });
    const proj = await createProject({
      title: 'طرح نرم‌افزار کابل',
      description: 'پروژه مستندسازی شهری',
      projectType: 'engineering',
      tags: ['کابل'],
    });
    const hash = await computeSHA256('kabul-doc');
    await registerDocument({
      projectId: proj.id,
      title: 'نقشه کابل',
      fileName: 'kabul_map.pdf',
      relativePath: '/Maps/kabul_map.pdf',
      mimeType: 'application/pdf',
      sizeBytes: 2048,
      sha256Hash: hash,
      storageSource: 'saf_tree',
      uriReference: 'saf://kabul_map.pdf',
      tags: ['کابل'],
    });

    // Test Arabic Kaf/Ya variant normalization ("كابل" matches "کابل")
    expect(normalizeDariText('كابل يادداشت')).toBe('کابل یادداشت');

    const allHits = executeUnifiedSearch({ query: 'كابل', selectedTags: ['کابل'] });
    const hitTypes = new Set(allHits.map((r) => r.type));
    expect(hitTypes.has('memory')).toBe(true);
    expect(hitTypes.has('project')).toBe(true);
    expect(hitTypes.has('document')).toBe(true);

    // Test fuzzy search ("کال" / 1 char typo "کابا" matches "کابل")
    const fuzzyHits = executeUnifiedSearch({ query: 'کابا', enableFuzzy: true });
    expect(fuzzyHits.length).toBeGreaterThanOrEqual(3);
  });

  it('Module 3 & Security: performs AES-256-GCM backup/restore, smart archiving, and SQLite VACUUM', async () => {
    const m = await createMemory({
      title: 'یادداشت قابل پشتیبان‌گیری',
      content: 'این رکورد باید پس از رمزنگاری و بازیابی حفظ شود',
    });
    const hash = await computeSHA256('dup');
    await registerDocument({
      title: 'فایل اصلی',
      fileName: 'a.bin',
      relativePath: '/a.bin',
      mimeType: 'application/octet-stream',
      sizeBytes: 4096,
      sha256Hash: hash,
      storageSource: 'saf_tree',
      uriReference: 'saf://a.bin',
    });
    await registerDocument({
      title: 'فایل تکراری',
      fileName: 'b.bin',
      relativePath: '/b.bin',
      mimeType: 'application/octet-stream',
      sizeBytes: 4096,
      sha256Hash: hash,
      storageSource: 'saf_tree',
      uriReference: 'saf://b.bin',
    });

    const suggestions = generateSmartArchiveSuggestions();
    expect(suggestions.length).toBeGreaterThanOrEqual(1);
    const archived = await runSmartArchiveBatch(suggestions);
    expect(archived).toBeGreaterThanOrEqual(1);

    // Export + AES-256-GCM encrypt + decrypt + safe restore
    const rawBytes = exportDatabaseBytes();
    const encrypted = await encryptBytesAESGCM(rawBytes, 'StrongPass14');
    await expect(decryptBytesAESGCM(encrypted, 'WrongPass')).rejects.toThrow();

    const decrypted = await decryptBytesAESGCM(encrypted, 'StrongPass14');
    const restored = await importDatabaseBytesSafely(decrypted);
    expect(restored.restoredVersion).toBe(3);
    expect(listMemories(true).some((item) => item.id === m.id)).toBe(true);
    expect(listDocuments(true).length).toBe(2);

    const maint = await runDatabaseMaintenance();
    expect(maint.integrityMessage.toLowerCase()).toBe('ok');
  });
});
