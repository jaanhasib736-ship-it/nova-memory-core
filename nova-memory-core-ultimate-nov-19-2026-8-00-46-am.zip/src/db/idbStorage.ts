const DB_NAME = 'nova_memory_core_ultimate_idb';
const DB_VERSION = 1;
const STORE_SQLITE = 'sqlite_binary';
const STORE_SAF = 'saf_handles';
const SQLITE_KEY = 'primary_database_v3';

function isIndexedDbAvailable(): boolean {
  return typeof indexedDB !== 'undefined';
}

function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!isIndexedDbAvailable()) {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const idb = req.result;
      if (!idb.objectStoreNames.contains(STORE_SQLITE)) {
        idb.createObjectStore(STORE_SQLITE);
      }
      if (!idb.objectStoreNames.contains(STORE_SAF)) {
        idb.createObjectStore(STORE_SAF, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Failed to open IndexedDB'));
  });
}

export async function loadPersistedSqliteBytes(): Promise<Uint8Array | null> {
  if (!isIndexedDbAvailable()) return null;
  try {
    const idb = await openIdb();
    return await new Promise<Uint8Array | null>((resolve, reject) => {
      const tx = idb.transaction(STORE_SQLITE, 'readonly');
      const store = tx.objectStore(STORE_SQLITE);
      const req = store.get(SQLITE_KEY);
      req.onsuccess = () => {
        const val = req.result;
        if (val instanceof Uint8Array) resolve(val);
        else if (val instanceof ArrayBuffer) resolve(new Uint8Array(val));
        else resolve(null);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function savePersistedSqliteBytes(bytes: Uint8Array): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  const idb = await openIdb();
  await new Promise<void>((resolve, reject) => {
    const tx = idb.transaction(STORE_SQLITE, 'readwrite');
    const store = tx.objectStore(STORE_SQLITE);
    const req = store.put(bytes, SQLITE_KEY);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export interface StoredSafFolder {
  id: string;
  name: string;
  handle?: FileSystemDirectoryHandle;
  addedAt: string;
  fileCount: number;
}

export async function saveSafFolderHandle(entry: StoredSafFolder): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  try {
    const idb = await openIdb();
    await new Promise<void>((resolve, reject) => {
      const tx = idb.transaction(STORE_SAF, 'readwrite');
      const req = tx.objectStore(STORE_SAF).put(entry);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Handle cloning may fail on restricted browsers; metadata still lives in SQLite
  }
}

export async function loadSafFolderHandles(): Promise<StoredSafFolder[]> {
  if (!isIndexedDbAvailable()) return [];
  try {
    const idb = await openIdb();
    return await new Promise<StoredSafFolder[]>((resolve, reject) => {
      const tx = idb.transaction(STORE_SAF, 'readonly');
      const req = tx.objectStore(STORE_SAF).getAll();
      req.onsuccess = () => resolve((req.result as StoredSafFolder[]) || []);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function removeSafFolderHandle(id: string): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  try {
    const idb = await openIdb();
    await new Promise<void>((resolve, reject) => {
      const tx = idb.transaction(STORE_SAF, 'readwrite');
      const req = tx.objectStore(STORE_SAF).delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // ignore
  }
}
