import type { Database } from 'sql.js';

export const CURRENT_SCHEMA_VERSION = 3;
export const NOVA_PACKAGE_ID = 'com.novamemory.core.ultimate';

function hasColumn(db: Database, table: string, column: string): boolean {
  const res = db.exec(`PRAGMA table_info(${table});`);
  if (!res.length) return false;
  return res[0].values.some((row) => String(row[1]) === column);
}

function getUserVersion(db: Database): number {
  const res = db.exec('PRAGMA user_version;');
  if (!res.length || !res[0].values.length) return 0;
  return Number(res[0].values[0][0]) || 0;
}

/**
 * Non-destructive schema migration runner.
 * Preserves all existing tables and user records when upgrading from v0/v1/v2 -> v3.
 */
export function runSafeMigrations(db: Database): { previousVersion: number; currentVersion: number } {
  const previousVersion = getUserVersion(db);

  db.run('PRAGMA foreign_keys = ON;');
  db.run('BEGIN TRANSACTION;');

  try {
    // V1 Core Tables (Module 1 & Security Config)
    db.run(`
      CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'عمومی',
        tags TEXT NOT NULL DEFAULT '[]',
        importance TEXT NOT NULL DEFAULT 'عادی',
        language TEXT NOT NULL DEFAULT 'fa-AF',
        is_pinned INTEGER NOT NULL DEFAULT 0,
        is_archived INTEGER NOT NULL DEFAULT 0,
        checksum TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS memory_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        memory_id INTEGER NOT NULL,
        previous_title TEXT NOT NULL,
        previous_content TEXT NOT NULL,
        previous_category TEXT NOT NULL,
        previous_tags TEXT NOT NULL DEFAULT '[]',
        change_note TEXT NOT NULL DEFAULT 'ویرایش حافظه',
        edited_at TEXT NOT NULL,
        FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
      );
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS personal_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        field_key TEXT NOT NULL,
        field_value TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'شخصی',
        is_sensitive INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
      );
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS security_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);

    // V2 Tables (Module 2: Projects & Documents Center)
    db.run(`
      CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        project_type TEXT NOT NULL DEFAULT 'research',
        status TEXT NOT NULL DEFAULT 'active',
        progress INTEGER NOT NULL DEFAULT 0,
        tags TEXT NOT NULL DEFAULT '[]',
        folder_path TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NULL,
        title TEXT NOT NULL,
        file_name TEXT NOT NULL,
        relative_path TEXT NOT NULL DEFAULT '',
        mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
        size_bytes INTEGER NOT NULL DEFAULT 0,
        sha256_hash TEXT NOT NULL,
        storage_source TEXT NOT NULL DEFAULT 'saf_tree',
        uri_reference TEXT NOT NULL DEFAULT '',
        integrity_status TEXT NOT NULL DEFAULT 'verified',
        last_verified_at TEXT NULL,
        is_archived INTEGER NOT NULL DEFAULT 0,
        tags TEXT NOT NULL DEFAULT '[]',
        notes TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
      );
    `);

    // V3 Tables (Module 3: Smart Intelligence, Archive & Recovery Journal)
    db.run(`
      CREATE TABLE IF NOT EXISTS archive_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_type TEXT NOT NULL,
        target_ref TEXT NOT NULL,
        details TEXT NOT NULL DEFAULT '',
        checksum TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'completed',
        created_at TEXT NOT NULL
      );
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS operation_journal (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'in_progress',
        started_at TEXT NOT NULL,
        completed_at TEXT NULL
      );
    `);

    // Column-level safe upgrades for pre-existing v1/v2 databases
    if (!hasColumn(db, 'memories', 'is_archived')) {
      db.run("ALTER TABLE memories ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;");
    }
    if (!hasColumn(db, 'memories', 'checksum')) {
      db.run("ALTER TABLE memories ADD COLUMN checksum TEXT NOT NULL DEFAULT '';");
    }
    if (!hasColumn(db, 'memories', 'language')) {
      db.run("ALTER TABLE memories ADD COLUMN language TEXT NOT NULL DEFAULT 'fa-AF';");
    }
    if (!hasColumn(db, 'documents', 'integrity_status')) {
      db.run("ALTER TABLE documents ADD COLUMN integrity_status TEXT NOT NULL DEFAULT 'verified';");
    }
    if (!hasColumn(db, 'documents', 'is_archived')) {
      db.run("ALTER TABLE documents ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;");
    }
    if (!hasColumn(db, 'documents', 'tags')) {
      db.run("ALTER TABLE documents ADD COLUMN tags TEXT NOT NULL DEFAULT '[]';");
    }
    if (!hasColumn(db, 'documents', 'notes')) {
      db.run("ALTER TABLE documents ADD COLUMN notes TEXT NOT NULL DEFAULT '';");
    }

    // Helpful indexes for fast search & duplicate detection
    db.run('CREATE INDEX IF NOT EXISTS idx_memories_updated ON memories(updated_at DESC);');
    db.run('CREATE INDEX IF NOT EXISTS idx_documents_sha256 ON documents(sha256_hash);');
    db.run('CREATE INDEX IF NOT EXISTS idx_documents_project ON documents(project_id);');
    db.run('CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);');
    db.run('CREATE INDEX IF NOT EXISTS idx_archive_logs_created ON archive_logs(created_at DESC);');

    // Ensure compatibility metadata defaults exist without overwriting user values
    const now = new Date().toISOString();
    const defaults: Array<[string, string]> = [
      ['package_id', NOVA_PACKAGE_ID],
      ['target_device', 'Samsung Galaxy A52 (Android 14)'],
      ['founder', 'Haseeb-ur-Rahman Sahibzada'],
      ['app_version', 'V3.0 COMPLETE'],
      ['auto_archive_days', '30'],
      ['low_storage_threshold_mb', '512'],
      ['large_file_threshold_mb', '10'],
      ['biometric_enabled', 'false'],
      ['pin_hash', ''],
      ['keystore_alias', 'nova_master_aes_gcm_v3'],
    ];

    const stmt = db.prepare(
      'INSERT OR IGNORE INTO security_settings (key, value, updated_at) VALUES (?, ?, ?);'
    );
    for (const [k, v] of defaults) {
      stmt.run([k, v, now]);
    }
    stmt.free();

    if (previousVersion < CURRENT_SCHEMA_VERSION) {
      db.run(`PRAGMA user_version = ${CURRENT_SCHEMA_VERSION};`);
    }

    db.run('COMMIT;');
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }

  return {
    previousVersion,
    currentVersion: CURRENT_SCHEMA_VERSION,
  };
}
