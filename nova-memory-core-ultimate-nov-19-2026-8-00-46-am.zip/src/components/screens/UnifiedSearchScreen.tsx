import React, { useMemo, useState } from 'react';
import {
  Archive,
  ArrowUpLeft,
  BookOpen,
  BrainCircuit,
  FolderKanban,
  Search,
  Sparkles,
  UserCheck,
  X,
} from 'lucide-react';
import { formatDateDari, toPersianDigits } from '../../services/androidBridge';
import {
  executeUnifiedSearch,
  getAllSearchableTags,
} from '../../services/searchService';
import type { NavigationIntent, UnifiedResultType, UnifiedSearchResult } from '../../types/nova';

interface UnifiedSearchScreenProps {
  initialQuery?: string;
  onNavigateIntent: (intent: NavigationIntent) => void;
}

const TYPE_FILTERS: Array<{ id: 'all' | UnifiedResultType; label: string }> = [
  { id: 'all', label: 'همه ماژول‌ها' },
  { id: 'memory', label: 'حافظه هوشمند' },
  { id: 'personal', label: 'اطلاعات شخصی' },
  { id: 'project', label: 'پروژه‌ها و کتاب‌ها' },
  { id: 'document', label: 'اسناد و فایل‌ها' },
  { id: 'archive', label: 'آرشیف و گزارش‌ها' },
];

const MATCH_LABELS: Record<UnifiedSearchResult['matchKind'], string> = {
  exact: 'تطابق دقیق',
  prefix: 'شروع واژه',
  keyword: 'کلیدواژه',
  tag: 'تطابق برچسب',
  fuzzy: 'تطابق فازی',
};

function getTypeIcon(type: UnifiedResultType) {
  switch (type) {
    case 'memory':
      return BrainCircuit;
    case 'personal':
      return UserCheck;
    case 'project':
      return FolderKanban;
    case 'document':
      return BookOpen;
    case 'archive':
      return Archive;
  }
}

export const UnifiedSearchScreen: React.FC<UnifiedSearchScreenProps> = ({
  initialQuery = '',
  onNavigateIntent,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [typeFilter, setTypeFilter] = useState<'all' | UnifiedResultType>('all');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [enableFuzzy, setEnableFuzzy] = useState(true);
  const [includeArchived, setIncludeArchived] = useState(true);
  const [sortBy, setSortBy] = useState<'relevance' | 'newest'>('relevance');

  const availableTags = useMemo(() => getAllSearchableTags(), [query, typeFilter]);

  const results = useMemo(() => {
    return executeUnifiedSearch({
      query,
      types: typeFilter === 'all' ? undefined : [typeFilter],
      selectedTags,
      enableFuzzy,
      includeArchived,
      sortBy,
    });
  }, [query, typeFilter, selectedTags, enableFuzzy, includeArchived, sortBy]);

  const countsByType = useMemo(() => {
    const map: Record<UnifiedResultType, number> = {
      memory: 0,
      personal: 0,
      project: 0,
      document: 0,
      archive: 0,
    };
    const allForCount = executeUnifiedSearch({
      query,
      selectedTags,
      enableFuzzy,
      includeArchived,
      sortBy,
    });
    for (const r of allForCount) {
      map[r.type] += 1;
    }
    return map;
  }, [query, selectedTags, enableFuzzy, includeArchived, sortBy]);

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-100">جستوجوی یکپارچه در کل سامانه نووا</h1>
        <p className="text-xs text-slate-400 mt-1">
          جستوجوی همزمان در حافظه‌های ماژول ۱، پروژه‌ها و اسناد SHA-256 ماژول ۲ و آرشیف هوشمند ماژول ۳ با پشتیبانی از تطابق فازی دری و فارسی
        </p>
      </div>

      {/* Unified Search Input & Controls */}
      <section className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 sm:p-5 space-y-4">
        <div className="relative">
          <Search className="h-5 w-5 text-emerald-400 absolute right-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="عبارت، نام پروژه، نام فایل، برچسب یا پیشوند هش SHA-256 را بنویسید..."
            className="w-full min-h-[50px] rounded-2xl border border-slate-700 bg-[#07101f] pr-12 pl-11 text-sm sm:text-base text-slate-100 placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="پاک کردن جستوجو"
              className="absolute left-2 top-1/2 -translate-y-1/2 min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Module Type Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5">
          {TYPE_FILTERS.map((tf) => {
            const active = typeFilter === tf.id;
            const count =
              tf.id === 'all'
                ? Object.values(countsByType).reduce((a, b) => a + b, 0)
                : countsByType[tf.id];
            return (
              <button
                key={tf.id}
                type="button"
                onClick={() => setTypeFilter(tf.id)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#07101f] text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {tf.label} ({toPersianDigits(count)})
              </button>
            );
          })}
        </div>

        {/* Interactive Tag Filter Controls */}
        {availableTags.length > 0 && (
          <div className="pt-2 border-t border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>فیلتر بر اساس برچسب‌ها</span>
              {selectedTags.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSelectedTags([])}
                  className="text-amber-300 hover:underline"
                >
                  حذف فیلتر برچسب‌ها
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {availableTags.slice(0, 14).map((t) => {
                const active = selectedTags.includes(t.tag);
                return (
                  <button
                    key={t.tag}
                    type="button"
                    onClick={() => toggleTag(t.tag)}
                    className={`min-h-[34px] px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-amber-500/20 text-amber-200 border border-amber-500/50'
                        : 'bg-[#07101f] text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {t.tag} · {toPersianDigits(t.count)}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Search Intelligence Toggles */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-2 cursor-pointer min-h-[36px]">
              <input
                type="checkbox"
                checked={enableFuzzy}
                onChange={(e) => setEnableFuzzy(e.target.checked)}
                className="rounded border-slate-600 bg-[#07101f] text-emerald-500"
              />
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>تطابق فازی و نرمال‌سازی دری/عربی (ی/ي، ک/ك)</span>
            </label>

            <label className="inline-flex items-center gap-2 cursor-pointer min-h-[36px]">
              <input
                type="checkbox"
                checked={includeArchived}
                onChange={(e) => setIncludeArchived(e.target.checked)}
                className="rounded border-slate-600 bg-[#07101f] text-emerald-500"
              />
              <span>شامل موارد آرشیف‌شده</span>
            </label>
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'relevance' | 'newest')}
            className="min-h-[38px] rounded-lg border border-slate-700 bg-[#07101f] px-3 text-xs text-slate-200"
          >
            <option value="relevance">مرتب‌سازی: مرتبط‌ترین</option>
            <option value="newest">مرتب‌سازی: جدیدترین</option>
          </select>
        </div>
      </section>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>
          نتایج یافت‌شده: <strong className="text-emerald-300 tabular-nums">{toPersianDigits(results.length)}</strong> رکورد در کل سامانه
        </span>
        {query.trim() && <span>کلیدواژه: «{query.trim()}»</span>}
      </div>

      {/* Results List */}
      {results.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-10 text-center space-y-2">
          <p className="text-sm text-slate-300">هیچ رکوردی مطابق جستوجو و فیلترهای انتخاب‌شده پیدا نشد.</p>
          <p className="text-xs text-slate-500">
            پیشنهاد: کلیدواژه کوتاه‌تر وارد کنید یا فیلتر برچسب‌ها را پاک نمایید.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((item) => {
            const Icon = getTypeIcon(item.type);
            return (
              <div
                key={item.uid}
                className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 sm:p-5 hover:border-emerald-500/45 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="min-w-0 space-y-1.5">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                      <Icon className="h-4 w-4" />
                      <span>{item.metaLabel}</span>
                    </span>
                    <span className="text-slate-600" aria-hidden="true">·</span>
                    <span className="text-xs text-amber-300">{MATCH_LABELS[item.matchKind]}</span>
                    <span className="text-slate-600" aria-hidden="true">·</span>
                    <span className="text-[11px] text-slate-500 tabular-nums">
                      {formatDateDari(item.updatedAt)}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-100">{item.title}</h3>
                  <div className="text-xs text-slate-400">{item.subtitle}</div>
                  {item.snippet && (
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-2">
                      {item.snippet}
                    </p>
                  )}
                  {item.tags.length > 0 && (
                    <div className="text-xs text-slate-500">
                      برچسب‌ها: {item.tags.join(' · ')}
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() =>
                    onNavigateIntent({
                      screen: item.targetScreen,
                      selectedId: item.id,
                      selectedType: item.type,
                    })
                  }
                  className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs sm:text-sm font-semibold text-emerald-300 hover:bg-emerald-500/20 whitespace-nowrap shrink-0"
                >
                  <span>باز کردن در {item.metaLabel}</span>
                  <ArrowUpLeft className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
