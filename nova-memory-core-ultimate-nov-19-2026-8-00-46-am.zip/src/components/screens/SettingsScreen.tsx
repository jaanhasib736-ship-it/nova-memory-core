import React, { useState } from 'react';
import { CheckCircle2, Database, RefreshCw, Smartphone, Terminal } from 'lucide-react';
import {
  getAllSettings,
  runDatabaseMaintenance,
  setSetting,
} from '../../db/sqliteEngine';
import { detectRuntimeCapabilities, formatBytesDari, toPersianDigits } from '../../services/androidBridge';
import { PWAInstallButton } from '../common/PWAInstallButton';
import type { DatabaseHealth } from '../../types/nova';

interface SettingsScreenProps {
  health: DatabaseHealth;
  onRefresh: () => Promise<void>;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ health, onRefresh }) => {
  const settings = getAllSettings();
  const [autoArchiveDays, setAutoArchiveDays] = useState(settings.auto_archive_days ?? '30');
  const [lowStorageMb, setLowStorageMb] = useState(settings.low_storage_threshold_mb ?? '512');
  const [largeFileMb, setLargeFileMb] = useState(settings.large_file_threshold_mb ?? '10');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [runningMaint, setRunningMaint] = useState(false);

  const capabilities = detectRuntimeCapabilities();

  const handleSaveThresholds = async (e: React.FormEvent) => {
    e.preventDefault();
    await setSetting('auto_archive_days', String(Math.max(1, Number(autoArchiveDays) || 30)));
    await setSetting('low_storage_threshold_mb', String(Math.max(64, Number(lowStorageMb) || 512)));
    await setSetting('large_file_threshold_mb', String(Math.max(1, Number(largeFileMb) || 10)));
    setStatusMsg('تنظیمات آستانه حافظه و آرشیف در پایگاه‌داده ذخیره شد.');
    await onRefresh();
  };

  const handleMaintenance = async () => {
    setRunningMaint(true);
    try {
      const res = await runDatabaseMaintenance();
      setStatusMsg(
        `بهینه‌سازی SQLite انجام شد · وضعیت سلامت: ${res.integrityMessage} · حجم: ${formatBytesDari(res.sizeBefore)} ← ${formatBytesDari(res.sizeAfter)}`
      );
      await onRefresh();
    } finally {
      setRunningMaint(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-100">تنظیمات سامانه، نگهداری پایگاه‌داده و نصب اندروید</h1>
        <p className="text-xs text-slate-400 mt-1">
          پیکربندی آستانه‌های هوشمند، نگهداری SQLite، نصب آفلاین PWA و دستورالعمل بیلد APK در ترموکس
        </p>
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3.5 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Automation Thresholds */}
        <form onSubmit={handleSaveThresholds} className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
          <h2 className="text-base font-bold text-slate-100">آستانه‌های هوشمند آرشیف و هشدار حافظه</h2>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                پیشنهاد آرشیف خودکار برای موارد بدون تغییر بیشتر از (روز)
              </label>
              <input
                type="number"
                min={1}
                value={autoArchiveDays}
                onChange={(e) => setAutoArchiveDays(e.target.value)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                آستانه هشدار کمبود فضای آزاد موبایل (مگابایت)
              </label>
              <input
                type="number"
                min={64}
                value={lowStorageMb}
                onChange={(e) => setLowStorageMb(e.target.value)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                آستانه شناسایی فایل حجیم (مگابایت)
              </label>
              <input
                type="number"
                min={1}
                value={largeFileMb}
                onChange={(e) => setLargeFileMb(e.target.value)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 tabular-nums"
              />
            </div>
          </div>

          <button
            type="submit"
            className="min-h-[44px] rounded-xl bg-emerald-600 px-5 text-sm font-semibold text-white hover:bg-emerald-500"
          >
            ذخیره تنظیمات
          </button>
        </form>

        {/* SQLite Maintenance & Stats */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Database className="h-4 w-4 text-emerald-400" />
              <span>نگهداری و سلامت SQLite</span>
            </h2>
            <span className="text-xs text-emerald-300 tabular-nums">
              نسخه اسکیما {toPersianDigits(health.schemaVersion)}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
              <span className="text-slate-400">حافظه‌ها</span>
              <div className="mt-1 text-base font-bold tabular-nums text-slate-100">
                {toPersianDigits(health.counts.memories)}
              </div>
            </div>
            <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
              <span className="text-slate-400">پروژه‌ها</span>
              <div className="mt-1 text-base font-bold tabular-nums text-slate-100">
                {toPersianDigits(health.counts.projects)}
              </div>
            </div>
            <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
              <span className="text-slate-400">اسناد ثبت‌شده</span>
              <div className="mt-1 text-base font-bold tabular-nums text-slate-100">
                {toPersianDigits(health.counts.documents)}
              </div>
            </div>
            <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
              <span className="text-slate-400">حجم پایگاه‌داده</span>
              <div className="mt-1 text-base font-bold tabular-nums text-amber-300">
                {formatBytesDari(health.dbSizeBytes)}
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={runningMaint}
            onClick={handleMaintenance}
            className="min-h-[44px] w-full inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 text-sm font-medium text-emerald-300 hover:bg-emerald-500/20"
          >
            <RefreshCw className={`h-4 w-4 ${runningMaint ? 'animate-spin' : ''}`} />
            <span>اجرای VACUUM، ANALYZE و بررسی سلامت جداول</span>
          </button>
        </div>
      </div>

      {/* PWA Install & Native Android 14 Build Instructions */}
      <section className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Smartphone className="h-5 w-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100">نصب روی Samsung Galaxy A52 (Android 14)</h2>
              <p className="text-xs text-slate-400">
                پشتیبانی کامل از حالت آفلاین PWA و سورس نیتیو اندروید در پوشه android-native
              </p>
            </div>
          </div>
          <PWAInstallButton />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
            <div className="text-slate-400">رابط SAF مرورگر</div>
            <div className="mt-1 text-slate-200">
              {capabilities.isFileSystemAccessSupported ? 'فعال (File System Access API)' : 'حالت سازگار انتخابگر پوشه'}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
            <div className="text-slate-400">پل بومی اندروید</div>
            <div className="mt-1 text-slate-200">
              {capabilities.isNativeAndroidBridge ? 'متصل به NovaAndroidBridge' : 'آماده در کد نیتیو Kotlin'}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-3">
            <div className="text-slate-400">بنیان‌گذار</div>
            <div className="mt-1 text-amber-300">حسیب‌الرحمن صاحب‌زاده</div>
          </div>
        </div>

        <div className="rounded-xl bg-[#07101f] border border-slate-800 p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <Terminal className="h-4 w-4" />
            <span>دستورهای ساخت و امضای APK در Termux (Android 14)</span>
          </div>
          <pre dir="ltr" className="text-[11px] font-mono-tabular text-slate-300 overflow-x-auto leading-relaxed">
{`npm install && npm run build
npx cap sync android
cd android && ./gradlew assembleRelease
# امضای سازگار با شناسه بسته اصلی:
apksigner sign --ks nova-release.keystore --out nova-v3-signed.apk app/build/outputs/apk/release/app-release-unsigned.apk`}
          </pre>
        </div>
      </section>
    </div>
  );
};
