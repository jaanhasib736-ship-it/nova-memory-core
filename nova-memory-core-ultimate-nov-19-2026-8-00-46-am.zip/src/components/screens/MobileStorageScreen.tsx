import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Copy, HardDrive, Layers, ShieldAlert } from 'lucide-react';
import { listDocuments, logArchiveAction, updateDocument } from '../../db/sqliteEngine';
import { formatBytesDari, toPersianDigits } from '../../services/androidBridge';
import { detectDuplicateDocuments } from '../../services/storageService';
import type { StorageReport } from '../../types/nova';

interface MobileStorageScreenProps {
  storageReport: StorageReport;
  onRefresh: () => Promise<void>;
}

export const MobileStorageScreen: React.FC<MobileStorageScreenProps> = ({
  storageReport,
  onRefresh,
}) => {
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const duplicates = detectDuplicateDocuments();
  const largeDocs = listDocuments(true)
    .filter((d) => d.sizeBytes >= 1024 * 1024)
    .sort((a, b) => b.sizeBytes - a.sizeBytes);

  const usedPct = Math.min(
    100,
    Math.round((storageReport.deviceUsageBytes / Math.max(1, storageReport.deviceQuotaBytes)) * 100)
  );

  const handleArchiveDuplicateRefs = async (docIds: number[]) => {
    for (const id of docIds) {
      await updateDocument(id, { isArchived: true });
    }
    await logArchiveAction({
      actionType: 'duplicate_resolved',
      targetRef: `${docIds.length} مرجع تکراری`,
      details: 'مراجع تکراری بر اساس SHA-256 بایگانی شدند (فایل‌های شخصی کاربر حذف نشدند)',
      status: 'verified',
    });
    setActionMsg(
      `${toPersianDigits(docIds.length)} مرجع تکراری با موفقیت بایگانی شد. هیچ فایل شخصی به صورت خودکار حذف نشد.`
    );
    await onRefresh();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-100">ماژول ۳: مدیریت حافظه موبایل و گزارش فضا</h1>
        <p className="text-xs text-slate-400 mt-1">
          پایش فضای آزاد و اشغال‌شده، شناسایی فایل‌های حجیم و کشف مراجع تکراری بر اساس امضای SHA-256
        </p>
      </div>

      {/* Main Storage Bar */}
      <section className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <HardDrive className="h-5 w-5 text-emerald-400" />
            <h2 className="text-base font-bold text-slate-100">گزارش فضای ذخیره‌سازی دستگاه</h2>
          </div>
          <span className="text-xs text-slate-300 tabular-nums">
            کل سهمیه در دسترس: {formatBytesDari(storageReport.deviceQuotaBytes)}
          </span>
        </div>

        <div className="h-3.5 w-full rounded-full bg-[#07101f] overflow-hidden border border-slate-800">
          <div
            className={`h-full transition-all ${
              storageReport.lowStorageWarning ? 'bg-amber-500' : 'bg-emerald-500'
            }`}
            style={{ width: `${Math.max(2, usedPct)}%` }}
          />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          <div className="rounded-xl bg-[#07101f] border border-slate-800/80 p-3.5">
            <div className="text-xs text-slate-400">فضای آزاد</div>
            <div className="mt-1 text-lg font-bold tabular-nums text-emerald-300">
              {formatBytesDari(storageReport.deviceAvailableBytes)}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800/80 p-3.5">
            <div className="text-xs text-slate-400">فضای اشغال‌شده</div>
            <div className="mt-1 text-lg font-bold tabular-nums text-slate-100">
              {formatBytesDari(storageReport.deviceUsageBytes)}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800/80 p-3.5">
            <div className="text-xs text-slate-400">اسناد ثبت‌شده</div>
            <div className="mt-1 text-lg font-bold tabular-nums text-amber-300">
              {formatBytesDari(storageReport.registeredDocumentsBytes)}
            </div>
          </div>
          <div className="rounded-xl bg-[#07101f] border border-slate-800/80 p-3.5">
            <div className="text-xs text-slate-400">فضای قابل آزادسازی (تکراری)</div>
            <div className="mt-1 text-lg font-bold tabular-nums text-emerald-300">
              {formatBytesDari(storageReport.reclaimableDuplicateBytes)}
            </div>
          </div>
        </div>
      </section>

      {actionMsg && (
        <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3.5 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{actionMsg}</span>
        </div>
      )}

      {/* Breakdown by Type & Large Files */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">تفکیک حجم بر اساس نوع اسناد</h2>
          </div>

          {storageReport.byMimeCategory.length === 0 ? (
            <p className="text-sm text-slate-400 py-4">هنوز سندی ثبت نشده است.</p>
          ) : (
            <div className="divide-y divide-slate-800">
              {storageReport.byMimeCategory.map((cat) => (
                <div key={cat.label} className="py-3 flex items-center justify-between text-sm">
                  <div>
                    <div className="font-medium text-slate-100">{cat.label}</div>
                    <div className="text-xs text-slate-400 tabular-nums">{toPersianDigits(cat.count)} فایل</div>
                  </div>
                  <div className="font-semibold tabular-nums text-emerald-300">{formatBytesDari(cat.bytes)}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100">فایل‌های حجیم (بالاتر از ۱ مگابایت)</h2>
          </div>

          {largeDocs.length === 0 ? (
            <p className="text-sm text-slate-400 py-4">فایل حجیمی ثبت نشده است.</p>
          ) : (
            <div className="divide-y divide-slate-800">
              {largeDocs.slice(0, 6).map((doc) => (
                <div key={doc.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-100 truncate">{doc.title}</div>
                    <div className="text-xs text-slate-400 truncate font-mono-tabular" dir="ltr">
                      {doc.relativePath || doc.fileName}
                    </div>
                  </div>
                  <span className="text-xs font-semibold tabular-nums text-amber-300 shrink-0">
                    {formatBytesDari(doc.sizeBytes)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Duplicate Detection Section */}
      <section className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Copy className="h-4 w-4 text-emerald-400" />
              <h2 className="text-base font-bold text-slate-100">
                شناسایی فایل‌های تکراری بر اساس SHA-256 ({toPersianDigits(duplicates.length)} گروه)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              سیاست ایمن نووا: هرگز فایل شخصی کاربر بدون تایید و پشتیبان حذف نمی‌شود؛ فقط می‌توانید مراجع اضافی را بایگانی کنید.
            </p>
          </div>
        </div>

        {duplicates.length === 0 ? (
          <div className="rounded-xl bg-[#07101f] border border-slate-800 p-5 text-sm text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span>در حال حاضر هیچ فایل تکراری با هش یکسان در کتابخانه اسناد وجود ندارد.</span>
          </div>
        ) : (
          <div className="space-y-3">
            {duplicates.map((grp) => {
              const extraIds = grp.documents.slice(1).filter((d) => !d.isArchived).map((d) => d.id);
              return (
                <div key={grp.sha256Hash} className="rounded-xl border border-amber-500/30 bg-[#07101f] p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-xs font-mono-tabular text-amber-300" dir="ltr">
                      SHA-256: {grp.sha256Hash.slice(0, 24)}…
                    </div>
                    <div className="text-xs text-slate-300 tabular-nums">
                      {toPersianDigits(grp.documents.length)} نسخه · حجم اضافه: {formatBytesDari(grp.totalWastedBytes)}
                    </div>
                  </div>

                  <div className="divide-y divide-slate-800/80">
                    {grp.documents.map((doc, idx) => (
                      <div key={doc.id} className="py-2 flex items-center justify-between text-xs">
                        <div className="min-w-0">
                          <span className="text-slate-100 font-medium">{doc.title}</span>
                          <span className="text-slate-500 mx-2">·</span>
                          <span className="font-mono-tabular text-slate-400" dir="ltr">
                            {doc.relativePath || doc.fileName}
                          </span>
                        </div>
                        <span className={idx === 0 ? 'text-emerald-400' : 'text-amber-300'}>
                          {idx === 0 ? 'نسخه مرجع اصلی' : doc.isArchived ? 'بایگانی‌شده' : 'نسخه تکراری'}
                        </span>
                      </div>
                    ))}
                  </div>

                  {extraIds.length > 0 && (
                    <button
                      type="button"
                      onClick={() => handleArchiveDuplicateRefs(extraIds)}
                      className="min-h-[40px] inline-flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3.5 text-xs font-medium text-amber-200 hover:bg-amber-500/20"
                    >
                      <ShieldAlert className="h-4 w-4" />
                      <span>بایگانی مراجع تکراری (بدون حذف فایل اصلی)</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
