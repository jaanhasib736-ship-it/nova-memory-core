export type ScreenId =
  | 'home'
  | 'memories'
  | 'projects'
  | 'documents'
  | 'storage'
  | 'archive'
  | 'search'
  | 'security'
  | 'settings';

export type MemoryCategory =
  | 'شخصی'
  | 'پژوهش'
  | 'پروژه'
  | 'ایده'
  | 'مالی و اسناد'
  | 'فنی'
  | 'عمومی';

export type MemoryImportance = 'عادی' | 'مهم' | 'حیاتی';

export interface MemoryRecord {
  id: number;
  title: string;
  content: string;
  category: MemoryCategory;
  tags: string[];
  importance: MemoryImportance;
  language: 'fa-AF' | 'fa' | 'en';
  isPinned: boolean;
  isArchived: boolean;
  checksum: string;
  createdAt: string;
  updatedAt: string;
}

export interface MemoryHistoryRecord {
  id: number;
  memoryId: number;
  previousTitle: string;
  previousContent: string;
  previousCategory: string;
  previousTags: string[];
  changeNote: string;
  editedAt: string;
}

export interface PersonalInfoRecord {
  id: number;
  fullName: string;
  fieldKey: string;
  fieldValue: string;
  category: string;
  isSensitive: boolean;
  updatedAt: string;
}

export type ProjectType = 'research' | 'book' | 'engineering' | 'personal';
export type ProjectStatus = 'active' | 'review' | 'completed' | 'archived';

export interface ProjectRecord {
  id: number;
  title: string;
  description: string;
  projectType: ProjectType;
  status: ProjectStatus;
  progress: number;
  tags: string[];
  folderPath: string;
  documentCount?: number;
  createdAt: string;
  updatedAt: string;
}

export type StorageSource = 'saf_tree' | 'mediastore' | 'file_picker' | 'internal';
export type IntegrityStatus = 'verified' | 'pending' | 'mismatch' | 'missing';

export interface DocumentRecord {
  id: number;
  projectId: number | null;
  projectTitle?: string;
  title: string;
  fileName: string;
  relativePath: string;
  mimeType: string;
  sizeBytes: number;
  sha256Hash: string;
  storageSource: StorageSource;
  uriReference: string;
  integrityStatus: IntegrityStatus;
  lastVerifiedAt: string | null;
  isArchived: boolean;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type ArchiveActionType =
  | 'backup_created'
  | 'backup_restored'
  | 'archive_moved'
  | 'integrity_scan'
  | 'db_vacuum'
  | 'duplicate_resolved'
  | 'recovery_checkpoint';

export interface ArchiveLogRecord {
  id: number;
  actionType: ArchiveActionType;
  targetRef: string;
  details: string;
  checksum: string;
  status: 'completed' | 'verified' | 'interrupted' | 'recovered';
  createdAt: string;
}

export interface DuplicateGroup {
  sha256Hash: string;
  fileSize: number;
  totalWastedBytes: number;
  documents: DocumentRecord[];
}

export interface ArchiveSuggestion {
  id: string;
  targetType: 'memory' | 'document';
  targetId: number;
  title: string;
  reason: string;
  ageDays: number;
  reclaimableBytes: number;
  priority: 'high' | 'medium' | 'low';
}

export interface StorageReport {
  deviceQuotaBytes: number;
  deviceUsageBytes: number;
  deviceAvailableBytes: number;
  registeredDocumentsBytes: number;
  sqliteDbBytes: number;
  archivedBytes: number;
  largeFilesCount: number;
  duplicateGroupsCount: number;
  reclaimableDuplicateBytes: number;
  lowStorageWarning: boolean;
  lowStorageThresholdMb: number;
  byMimeCategory: Array<{
    label: string;
    bytes: number;
    count: number;
  }>;
}

export type UnifiedResultType = 'memory' | 'personal' | 'project' | 'document' | 'archive';

export interface UnifiedSearchResult {
  uid: string;
  type: UnifiedResultType;
  id: number;
  title: string;
  subtitle: string;
  snippet: string;
  tags: string[];
  score: number;
  matchKind: 'exact' | 'prefix' | 'keyword' | 'tag' | 'fuzzy';
  updatedAt: string;
  targetScreen: ScreenId;
  metaLabel: string;
}

export interface DatabaseHealth {
  schemaVersion: number;
  packageId: string;
  integrityOk: boolean;
  integrityMessage: string;
  dbSizeBytes: number;
  counts: {
    memories: number;
    memoryHistory: number;
    personalRecords: number;
    projects: number;
    documents: number;
    archiveLogs: number;
  };
  recoveredOperations: number;
  lastSavedAt: string | null;
}

export interface EncryptedBackupEnvelope {
  format: 'NOVA_MEMORY_BACKUP_V3';
  packageId: string;
  schemaVersion: number;
  createdAt: string;
  cipher: 'AES-256-GCM';
  kdf: 'PBKDF2-SHA256';
  iterations: number;
  saltBase64: string;
  ivBase64: string;
  plaintextSha256: string;
  ciphertextBase64: string;
}

export interface NavigationIntent {
  screen: ScreenId;
  selectedId?: number;
  selectedType?: UnifiedResultType;
  searchQuery?: string;
}
