import React, { useEffect, useState } from 'react';
import {
  Archive,
  Edit3,
  Eye,
  EyeOff,
  History,
  Pin,
  Plus,
  Search,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import {
  autoCategorizeMemory,
  createMemory,
  deleteMemory,
  deletePersonalRecord,
  getMemoryHistory,
  listMemories,
  listPersonalRecords,
  updateMemory,
  upsertPersonalRecord,
} from '../../db/sqliteEngine';
import { formatDateDari, toPersianDigits } from '../../services/androidBridge';
import { normalizeDariText } from '../../services/searchService';
import type {
  MemoryCategory,
  MemoryHistoryRecord,
  MemoryImportance,
  MemoryRecord,
  PersonalInfoRecord,
} from '../../types/nova';

const CATEGORIES: MemoryCategory[] = ['عمومی', 'شخصی', 'پژوهش', 'پروژه', 'ایده', 'مالی و اسناد', 'فنی'];
const IMPORTANCES: MemoryImportance[] = ['عادی', 'مهم', 'حیاتی'];

interface SmartMemoryScreenProps {
  highlightedId?: number;
  onRefresh: () => Promise<void>;
}

export const SmartMemoryScreen: React.FC<SmartMemoryScreenProps> = ({ highlightedId, onRefresh }) => {
  const [activeTab, setActiveTab] = useState<'memories' | 'personal'>('memories');
  const [filterCategory, setFilterCategory] = useState<string>('همه');
  const [showArchived, setShowArchived] = useState(false);
  const [searchInput, setSearchInput] = useState('');

  // Form modal state for Memories
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingMemory, setEditingMemory] = useState<MemoryRecord | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<MemoryCategory>('عمومی');
  const [autoCat, setAutoCat] = useState(true);
  const [tagsRaw, setTagsRaw] = useState('');
  const [importance, setImportance] = useState<MemoryImportance>('عادی');
  const [isPinned, setIsPinned] = useState(false);
  const [changeNote, setChangeNote] = useState('');

  // History modal
  const [historyMemory, setHistoryMemory] = useState<MemoryRecord | null>(null);
  const [historyRows, setHistoryRows] = useState<MemoryHistoryRecord[]>([]);

  // Personal info state
  const [personalFormOpen, setPersonalFormOpen] = useState(false);
  const [pId, setPId] = useState<number | undefined>(undefined);
  const [pFullName, setPFullName] = useState('حسیب‌الرحمن صاحب‌زاده');
  const [pKey, setPKey] = useState('');
  const [pValue, setPValue] = useState('');
  const [pCategory, setPCategory] = useState('شخصی');
  const [pSensitive, setPSensitive] = useState(false);
  const [revealedIds, setRevealedIds] = useState<Set<number>>(new Set());

  const memories = listMemories(showArchived);
  const personalRecords = listPersonalRecords();

  useEffect(() => {
    if (highlightedId) {
      const target = listMemories(true).find((m) => m.id === highlightedId);
      if (target) {
        if (target.isArchived) setShowArchived(true);
        openEditModal(target);
      } else {
        const pTarget = listPersonalRecords().find((p) => p.id === highlightedId);
        if (pTarget) setActiveTab('personal');
      }
    }
  }, [highlightedId]);

  const openNewModal = () => {
    setEditingMemory(null);
    setTitle('');
    setContent('');
    setCategory('عمومی');
    setAutoCat(true);
    setTagsRaw('');
    setImportance('عادی');
    setIsPinned(false);
    setChangeNote('');
    setEditorOpen(true);
  };

  const openEditModal = (mem: MemoryRecord) => {
    setEditingMemory(mem);
    setTitle(mem.title);
    setContent(mem.content);
    setCategory(mem.category);
    setAutoCat(false);
    setTagsRaw(mem.tags.join('، '));
    setImportance(mem.importance);
    setIsPinned(mem.isPinned);
    setChangeNote('');
    setEditorOpen(true);
  };

  const openHistory = (mem: MemoryRecord) => {
    setHistoryMemory(mem);
    setHistoryRows(getMemoryHistory(mem.id));
  };

  const handleSaveMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    const tags = tagsRaw
      .split(/[,،]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    const resolvedCat = autoCat ? autoCategorizeMemory(title, content) : category;

    if (editingMemory) {
      await updateMemory(editingMemory.id, {
        title,
        content,
        category: resolvedCat,
        tags,
        importance,
        isPinned,
        changeNote: changeNote.trim() || 'ویرایش دستی در حافظه هوشمند',
      });
    } else {
      await createMemory({
        title,
        content,
        category: resolvedCat,
        tags,
        importance,
        isPinned,
      });
    }
    setEditorOpen(false);
    await onRefresh();
  };

  const handleTogglePin = async (mem: MemoryRecord) => {
    await updateMemory(mem.id, { isPinned: !mem.isPinned });
    await onRefresh();
  };

  const handleToggleArchive = async (mem: MemoryRecord) => {
    await updateMemory(mem.id, {
      isArchived: !mem.isArchived,
      changeNote: mem.isArchived ? 'بازگردانی از آرشیف' : 'انتقال به آرشیف',
    });
    await onRefresh();
  };

  const handleDeleteMemory = async (id: number) => {
    await deleteMemory(id);
    await onRefresh();
  };

  const handleSavePersonal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pKey.trim() || !pValue.trim()) return;
    await upsertPersonalRecord({
      id: pId,
      fullName: pFullName.trim() || 'حسیب‌الرحمن صاحب‌زاده',
      fieldKey: pKey.trim(),
      fieldValue: pValue.trim(),
      category: pCategory.trim() || 'شخصی',
      isSensitive: pSensitive,
    });
    setPersonalFormOpen(false);
    setPId(undefined);
    setPKey('');
    setPValue('');
    await onRefresh();
  };

  const openEditPersonal = (rec: PersonalInfoRecord) => {
    setPId(rec.id);
    setPFullName(rec.fullName);
    setPKey(rec.fieldKey);
    setPValue(rec.fieldValue);
    setPCategory(rec.category);
    setPSensitive(rec.isSensitive);
    setPersonalFormOpen(true);
  };

  const filteredMemories = memories.filter((m) => {
    if (filterCategory !== 'همه' && m.category !== filterCategory) return false;
    if (!searchInput.trim()) return true;
    const q = normalizeDariText(searchInput);
    return (
      normalizeDariText(m.title).includes(q) ||
      normalizeDariText(m.content).includes(q) ||
      m.tags.some((t) => normalizeDariText(t).includes(q))
    );
  });

  return (
    <div className="space-y-5">
      {/* Header & Module Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100">ماژول ۱: حافظه هوشمند و اطلاعات شخصی</h1>
          <p className="text-xs text-slate-400 mt-1">
            ثبت خودکار و دستی، دسته‌بندی هوشمند دری/فارسی، تاریخچه ویرایش و مدیریت سوابق شخصی
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-xl bg-[#0d1b30] p-1 border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('memories')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'memories' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              حافظه‌ها ({toPersianDigits(memories.length)})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('personal')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'personal' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              اطلاعات شخصی ({toPersianDigits(personalRecords.length)})
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'memories' ? (
        <>
          {/* Filter & Action Toolbar */}
          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 space-y-3">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="h-4 w-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder="جستوجو در عنوان، متن و برچسب‌های حافظه..."
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] pr-10 pl-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <button
                type="button"
                onClick={openNewModal}
                className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 whitespace-nowrap shrink-0"
              >
                <Plus className="h-4 w-4" />
                <span>ثبت حافظه جدید</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                {['همه', ...CATEGORIES].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setFilterCategory(cat)}
                    className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                      filterCategory === cat
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-[#07101f] text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-300 cursor-pointer min-h-[36px]">
                <input
                  type="checkbox"
                  checked={showArchived}
                  onChange={(e) => setShowArchived(e.target.checked)}
                  className="rounded border-slate-600 bg-[#07101f] text-emerald-500"
                />
                <span>نمایش موارد آرشیف‌شده</span>
              </label>
            </div>
          </div>

          {/* Memory Cards List */}
          {filteredMemories.length === 0 ? (
            <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-10 text-center space-y-3">
              <p className="text-sm text-slate-300">حافظه‌ای با این فیلتر یافت نشد.</p>
              <button
                type="button"
                onClick={openNewModal}
                className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
              >
                <Plus className="h-4 w-4" />
                <span>ثبت اولین حافظه</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredMemories.map((mem) => (
                <article
                  key={mem.id}
                  className={`rounded-2xl border p-5 flex flex-col justify-between transition-colors ${
                    highlightedId === mem.id
                      ? 'border-amber-400 bg-[#132540]'
                      : 'border-slate-800 bg-[#0d1b30] hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="text-base font-bold text-slate-100 leading-snug">{mem.title}</h3>
                      <button
                        type="button"
                        onClick={() => handleTogglePin(mem)}
                        title={mem.isPinned ? 'برداشتن سنجاق' : 'سنجاق کردن'}
                        className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg ${
                          mem.isPinned ? 'text-amber-400 bg-amber-500/10' : 'text-slate-500 hover:text-slate-200'
                        }`}
                      >
                        <Pin className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="text-emerald-300 font-medium">{mem.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>اهمیت: {mem.importance}</span>
                      {mem.isArchived && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300">آرشیف‌شده</span>
                        </>
                      )}
                      {mem.tags.length > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{mem.tags.join('، ')}</span>
                        </>
                      )}
                    </div>

                    <p className="mt-3 text-sm text-slate-200 leading-relaxed whitespace-pre-line">
                      {mem.content}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500 tabular-nums">
                      به‌روزرسانی: {formatDateDari(mem.updatedAt)}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openHistory(mem)}
                        className="min-h-[36px] px-2.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800 inline-flex items-center gap-1"
                        title="تاریخچه ویرایش"
                      >
                        <History className="h-3.5 w-3.5 text-amber-400" />
                        <span>تاریخچه</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => openEditModal(mem)}
                        className="min-h-[36px] px-2.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800 inline-flex items-center gap-1"
                      >
                        <Edit3 className="h-3.5 w-3.5 text-emerald-400" />
                        <span>ویرایش</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleArchive(mem)}
                        className="min-h-[36px] px-2 rounded-lg text-xs text-slate-400 hover:bg-slate-800 hover:text-amber-300"
                        title={mem.isArchived ? 'بازگردانی' : 'آرشیف'}
                      >
                        <Archive className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteMemory(mem.id)}
                        className="min-h-[36px] px-2 rounded-lg text-xs text-slate-500 hover:bg-rose-500/10 hover:text-rose-400"
                        title="حذف رکورد حافظه"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </>
      ) : (
        /* Personal Information Vault Tab */
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-sm text-slate-200">
              <UserCheck className="h-5 w-5 text-emerald-400" />
              <span>مدیریت اطلاعات هویتی، تماس و مشخصات کلیدی به صورت کاملاً آفلاین</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setPId(undefined);
                setPKey('');
                setPValue('');
                setPSensitive(false);
                setPersonalFormOpen(true);
              }}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              <span>افزودن اطلاعات شخصی</span>
            </button>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] divide-y divide-slate-800">
            {personalRecords.map((rec) => {
              const revealed = revealedIds.has(rec.id);
              return (
                <div key={rec.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-slate-100">{rec.fieldKey}</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      {rec.fullName} · {rec.category}
                    </div>
                    <div className="mt-1.5 text-sm font-mono-tabular text-emerald-300">
                      {rec.isSensitive && !revealed ? '••••••••••••' : rec.fieldValue}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {rec.isSensitive && (
                      <button
                        type="button"
                        onClick={() => {
                          const next = new Set(revealedIds);
                          if (revealed) next.delete(rec.id);
                          else next.add(rec.id);
                          setRevealedIds(next);
                        }}
                        className="min-h-[38px] px-3 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800 inline-flex items-center gap-1.5"
                      >
                        {revealed ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        <span>{revealed ? 'پنهان' : 'نمایش'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => openEditPersonal(rec)}
                      className="min-h-[38px] px-3 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800"
                    >
                      ویرایش
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await deletePersonalRecord(rec.id);
                        await onRefresh();
                      }}
                      className="min-h-[38px] px-2.5 rounded-lg text-xs text-rose-400 hover:bg-rose-500/10"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Memory Create/Edit Modal */}
      {editorOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveMemory}
            className="w-full max-w-xl rounded-2xl border border-slate-700 bg-[#0d1b30] p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-slate-100">
                {editingMemory ? 'ویرایش حافظه و ثبت در تاریخچه' : 'ثبت حافظه هوشمند جدید'}
              </h2>
              <button
                type="button"
                onClick={() => setEditorOpen(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 mb-1">عنوان</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">متن کامل حافظه</label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-[#07101f] p-3.5 text-sm text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs text-slate-300">دسته‌بندی</label>
                    <label className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={autoCat}
                        onChange={(e) => setAutoCat(e.target.checked)}
                      />
                      <span>تشخیص خودکار</span>
                    </label>
                  </div>
                  <select
                    disabled={autoCat}
                    value={autoCat ? autoCategorizeMemory(title, content) : category}
                    onChange={(e) => setCategory(e.target.value as MemoryCategory)}
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100 disabled:opacity-60"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-300 mb-1">درجه اهمیت</label>
                  <select
                    value={importance}
                    onChange={(e) => setImportance(e.target.value as MemoryImportance)}
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
                  >
                    {IMPORTANCES.map((imp) => (
                      <option key={imp} value={imp}>
                        {imp}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">برچسب‌ها (با کاما یا ویرگول جدا کنید)</label>
                <input
                  type="text"
                  value={tagsRaw}
                  onChange={(e) => setTagsRaw(e.target.value)}
                  placeholder="مثلاً: پژوهش، دری، اندروید"
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              {editingMemory && (
                <div>
                  <label className="block text-xs text-slate-300 mb-1">توضیح ویرایش (برای ثبت در تاریخچه)</label>
                  <input
                    type="text"
                    value={changeNote}
                    onChange={(e) => setChangeNote(e.target.value)}
                    placeholder="تکمیل نکات یا اصلاح متن..."
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
                  />
                </div>
              )}

              <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                <input type="checkbox" checked={isPinned} onChange={(e) => setIsPinned(e.target.checked)} />
                <span>سنجاق در بالای فهرست و محافظت در برابر آرشیف خودکار</span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditorOpen(false)}
                className="min-h-[44px] px-4 rounded-xl border border-slate-700 text-sm text-slate-300 hover:bg-slate-800"
              >
                انصراف
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-xl bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500"
              >
                ذخیره نهایی
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Memory Edit History Modal */}
      {historyMemory && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl border border-slate-700 bg-[#0d1b30] p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-100">تاریخچه تغییرات حافظه</h2>
                <p className="text-xs text-slate-400 mt-0.5">{historyMemory.title}</p>
              </div>
              <button
                type="button"
                onClick={() => setHistoryMemory(null)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {historyRows.length === 0 ? (
              <p className="text-sm text-slate-400 py-4">
                هنوز ویرایشی برای این حافظه ثبت نشده است. با هر ویرایش، نسخه قبلی به طور خودکار در SQLite نگهداری می‌شود.
              </p>
            ) : (
              <div className="space-y-3">
                {historyRows.map((h) => (
                  <div key={h.id} className="rounded-xl border border-slate-800 bg-[#07101f] p-3.5 space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-amber-300">
                      <span>{h.changeNote}</span>
                      <span className="tabular-nums text-slate-400">{formatDateDari(h.editedAt)}</span>
                    </div>
                    <div className="text-sm font-semibold text-slate-200">{h.previousTitle}</div>
                    <p className="text-xs text-slate-400 leading-relaxed">{h.previousContent}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Personal Info Modal */}
      {personalFormOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSavePersonal}
            className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#0d1b30] p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-slate-100">ثبت / ویرایش اطلاعات شخصی</h2>
              <button
                type="button"
                onClick={() => setPersonalFormOpen(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3">
              <input
                type="text"
                value={pFullName}
                onChange={(e) => setPFullName(e.target.value)}
                placeholder="نام صاحب اطلاعات"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
              <input
                type="text"
                required
                value={pKey}
                onChange={(e) => setPKey(e.target.value)}
                placeholder="عنوان فیلد (مثلاً شماره تذکره، آدرس دفتر...)"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
              <input
                type="text"
                required
                value={pValue}
                onChange={(e) => setPValue(e.target.value)}
                placeholder="مقدار"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
              <input
                type="text"
                value={pCategory}
                onChange={(e) => setPCategory(e.target.value)}
                placeholder="دسته (شخصی، تماس، فنی...)"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
              <label className="inline-flex items-center gap-2 text-xs text-slate-300">
                <input type="checkbox" checked={pSensitive} onChange={(e) => setPSensitive(e.target.checked)} />
                <span>فیلد محرمانه (نمایان فقط با کلیک)</span>
              </label>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPersonalFormOpen(false)}
                className="min-h-[44px] px-4 rounded-xl border border-slate-700 text-sm text-slate-300"
              >
                لغو
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-xl bg-emerald-600 text-sm font-semibold text-white"
              >
                ذخیره
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
