import { useCallback, useEffect, useState } from 'react';
import { AppShell } from './components/layout/AppShell';
import { DocumentsScreen } from './components/screens/DocumentsScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { MobileStorageScreen } from './components/screens/MobileStorageScreen';
import { ProjectsScreen } from './components/screens/ProjectsScreen';
import { SecurityScreen } from './components/screens/SecurityScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { SmartArchiveScreen } from './components/screens/SmartArchiveScreen';
import { SmartMemoryScreen } from './components/screens/SmartMemoryScreen';
import { UnifiedSearchScreen } from './components/screens/UnifiedSearchScreen';
import { LockScreenModal } from './components/security/LockScreenModal';
import {
  getDatabaseHealth,
  getSetting,
  initializeDatabase,
} from './db/sqliteEngine';
import {
  generateSmartArchiveSuggestions,
  generateStorageReport,
} from './services/storageService';
import type {
  ArchiveSuggestion,
  DatabaseHealth,
  NavigationIntent,
  ScreenId,
  StorageReport,
} from './types/nova';

export default function App() {
  const [ready, setReady] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);

  const [activeScreen, setActiveScreen] = useState<ScreenId>('home');
  const [highlightedId, setHighlightedId] = useState<number | undefined>(undefined);
  const [initialSearchQuery, setInitialSearchQuery] = useState<string>('');
  const [health, setHealth] = useState<DatabaseHealth | null>(null);
  const [storageReport, setStorageReport] = useState<StorageReport | null>(null);
  const [suggestions, setSuggestions] = useState<ArchiveSuggestion[]>([]);

  const refreshState = useCallback(async () => {
    const dbHealth = getDatabaseHealth();
    const report = await generateStorageReport();
    const archSuggestions = generateSmartArchiveSuggestions();
    setHealth(dbHealth);
    setStorageReport(report);
    setSuggestions(archSuggestions);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await initializeDatabase();
        if (!mounted) return;
        const hasPin = Boolean(getSetting('pin_hash', ''));
        setLocked(hasPin);
        await refreshState();
        if (mounted) setReady(true);
      } catch (err) {
        if (mounted) {
          setInitError(err instanceof Error ? err.message : 'خطا در راه‌اندازی پایگاه‌داده SQLite');
        }
      }
    })();
    return () => {
      mounted = false;
    };
  }, [refreshState]);

  const handleNavigate = (screen: ScreenId) => {
    setHighlightedId(undefined);
    setActiveScreen(screen);
  };

  const handleNavigateIntent = (intent: NavigationIntent) => {
    setHighlightedId(intent.selectedId);
    if (intent.searchQuery !== undefined) {
      setInitialSearchQuery(intent.searchQuery);
    }
    setActiveScreen(intent.screen);
  };

  if (initError) {
    return (
      <div className="min-h-screen bg-[#07101f] text-slate-100 flex items-center justify-center p-6">
        <div className="max-w-md rounded-2xl border border-rose-500/40 bg-[#0d1b30] p-6 space-y-3">
          <h1 className="text-lg font-bold text-rose-300">خطا در راه‌اندازی هسته نووا</h1>
          <p className="text-sm text-slate-300">{initError}</p>
        </div>
      </div>
    );
  }

  if (!ready || !health || !storageReport) {
    return (
      <div className="min-h-screen bg-[#07101f] text-slate-100 flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <img src="/icon.svg" alt="NOVA" className="h-14 w-14 mx-auto" referrerPolicy="no-referrer" />
          <div className="text-base font-bold text-slate-100">NOVA MEMORY CORE ULTIMATE</div>
          <div className="text-xs text-emerald-300">در حال آماده‌سازی پایگاه‌داده آفلاین SQLite…</div>
        </div>
      </div>
    );
  }

  return (
    <>
      {locked && <LockScreenModal onUnlock={() => setLocked(false)} />}

      <AppShell
        activeScreen={activeScreen}
        onNavigate={handleNavigate}
        onQuickSearchOpen={() => handleNavigateIntent({ screen: 'search' })}
      >
        {activeScreen === 'home' && (
          <HomeScreen
            health={health}
            storageReport={storageReport}
            suggestions={suggestions}
            onRefresh={refreshState}
            onNavigateIntent={handleNavigateIntent}
          />
        )}

        {activeScreen === 'memories' && (
          <SmartMemoryScreen highlightedId={highlightedId} onRefresh={refreshState} />
        )}

        {activeScreen === 'projects' && (
          <ProjectsScreen
            highlightedId={highlightedId}
            onRefresh={refreshState}
            onNavigateIntent={handleNavigateIntent}
          />
        )}

        {activeScreen === 'documents' && (
          <DocumentsScreen highlightedId={highlightedId} onRefresh={refreshState} />
        )}

        {activeScreen === 'storage' && (
          <MobileStorageScreen storageReport={storageReport} onRefresh={refreshState} />
        )}

        {activeScreen === 'archive' && (
          <SmartArchiveScreen suggestions={suggestions} onRefresh={refreshState} />
        )}

        {activeScreen === 'search' && (
          <UnifiedSearchScreen
            initialQuery={initialSearchQuery}
            onNavigateIntent={handleNavigateIntent}
          />
        )}

        {activeScreen === 'security' && (
          <SecurityScreen onLockNow={() => setLocked(true)} onRefresh={refreshState} />
        )}

        {activeScreen === 'settings' && <SettingsScreen health={health} onRefresh={refreshState} />}
      </AppShell>
    </>
  );
}
