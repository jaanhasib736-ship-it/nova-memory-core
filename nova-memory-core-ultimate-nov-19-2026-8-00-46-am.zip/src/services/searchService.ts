import {
  listArchiveLogs,
  listDocuments,
  listMemories,
  listPersonalRecords,
  listProjects,
} from '../db/sqliteEngine';
import type { UnifiedResultType, UnifiedSearchResult } from '../types/nova';

/**
 * Normalizes Dari / Persian / Arabic variants for intelligent cross-script matching:
 * - ي / ى -> ی
 * - ك -> ک
 * - ة -> ه
 * - أ / إ / آ -> ا
 * - Persian & Arabic digits -> ASCII 0-9
 * - Removes Arabic diacritics & ZWNJ noise
 */
export function normalizeDariText(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '') // diacritics
    .replace(/\u200c/g, ' ') // ZWNJ to space for flexible token matching
    .replace(/[يیى]/g, 'ی')
    .replace(/[كک]/g, 'ک')
    .replace(/[ةه]/g, 'ه')
    .replace(/[أإآ]/g, 'ا')
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/\s+/g, ' ')
    .trim();
}

export function levenshteinDistance(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;

  const prev = new Array<number>(b.length + 1);
  const curr = new Array<number>(b.length + 1);

  for (let j = 0; j <= b.length; j++) prev[j] = j;

  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = curr[j];
  }
  return prev[b.length];
}

function scoreField(
  rawField: string,
  queryNorm: string,
  queryTokens: string[],
  enableFuzzy: boolean
): { score: number; matchKind: UnifiedSearchResult['matchKind'] } {
  const norm = normalizeDariText(rawField);
  if (!norm || !queryNorm) return { score: 0, matchKind: 'keyword' };

  if (norm === queryNorm) return { score: 120, matchKind: 'exact' };
  if (norm.startsWith(queryNorm)) return { score: 95, matchKind: 'prefix' };
  if (norm.includes(queryNorm)) return { score: 80, matchKind: 'keyword' };

  // Token-level matching
  const fieldTokens = norm.split(/\s+/);
  let tokenHits = 0;
  let fuzzyHits = 0;

  for (const qt of queryTokens) {
    if (qt.length < 2) continue;
    if (norm.includes(qt)) {
      tokenHits++;
      continue;
    }
    if (enableFuzzy && qt.length >= 3) {
      const maxDist = qt.length >= 6 ? 2 : 1;
      const hasFuzzy = fieldTokens.some((ft) => Math.abs(ft.length - qt.length) <= maxDist && levenshteinDistance(ft, qt) <= maxDist);
      if (hasFuzzy) fuzzyHits++;
    }
  }

  if (tokenHits > 0) {
    const ratio = tokenHits / Math.max(1, queryTokens.length);
    return { score: Math.round(45 + ratio * 30), matchKind: 'keyword' };
  }
  if (fuzzyHits > 0) {
    const ratio = fuzzyHits / Math.max(1, queryTokens.length);
    return { score: Math.round(28 + ratio * 20), matchKind: 'fuzzy' };
  }
  return { score: 0, matchKind: 'keyword' };
}

function buildSnippet(text: string, queryNorm: string): string {
  const cleaned = text.replace(/\s+/g, ' ').trim();
  if (cleaned.length <= 150) return cleaned;
  if (!queryNorm) return `${cleaned.slice(0, 145)}…`;

  const norm = normalizeDariText(cleaned);
  const idx = norm.indexOf(queryNorm.split(' ')[0] ?? '');
  if (idx <= 25) return `${cleaned.slice(0, 145)}…`;
  const start = Math.max(0, idx - 35);
  return `…${cleaned.slice(start, start + 145)}…`;
}

export interface UnifiedSearchOptions {
  query: string;
  types?: UnifiedResultType[];
  selectedTags?: string[];
  includeArchived?: boolean;
  enableFuzzy?: boolean;
  sortBy?: 'relevance' | 'newest';
}

export function getAllSearchableTags(): Array<{ tag: string; count: number }> {
  const counts = new Map<string, number>();
  const addTags = (tags: string[]) => {
    for (const t of tags) {
      const clean = t.trim();
      if (!clean) continue;
      counts.set(clean, (counts.get(clean) ?? 0) + 1);
    }
  };

  listMemories(true).forEach((m) => addTags(m.tags));
  listProjects().forEach((p) => addTags(p.tags));
  listDocuments(true).forEach((d) => addTags(d.tags));

  return Array.from(counts.entries())
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count);
}

export function executeUnifiedSearch(options: UnifiedSearchOptions): UnifiedSearchResult[] {
  const queryNorm = normalizeDariText(options.query);
  const queryTokens = queryNorm.split(/\s+/).filter(Boolean);
  const enableFuzzy = options.enableFuzzy !== false;
  const includeArchived = options.includeArchived !== false;
  const allowedTypes = new Set<UnifiedResultType>(
    options.types && options.types.length ? options.types : ['memory', 'personal', 'project', 'document', 'archive']
  );
  const requiredTags = (options.selectedTags ?? []).map(normalizeDariText);

  const hasTagMatch = (tags: string[]) => {
    if (!requiredTags.length) return true;
    const normTags = tags.map(normalizeDariText);
    return requiredTags.every((rt) => normTags.some((nt) => nt.includes(rt)));
  };

  const results: UnifiedSearchResult[] = [];

  // Module 1: Memories
  if (allowedTypes.has('memory')) {
    for (const mem of listMemories(includeArchived)) {
      if (!hasTagMatch(mem.tags)) continue;
      let bestScore = 0;
      let matchKind: UnifiedSearchResult['matchKind'] = 'keyword';

      if (!queryNorm) {
        bestScore = mem.isPinned ? 70 : 50;
      } else {
        const titleEval = scoreField(mem.title, queryNorm, queryTokens, enableFuzzy);
        const bodyEval = scoreField(mem.content, queryNorm, queryTokens, enableFuzzy);
        const catEval = scoreField(mem.category, queryNorm, queryTokens, enableFuzzy);
        const tagHit = mem.tags.some((t) => normalizeDariText(t).includes(queryNorm));

        const weighted = Math.max(
          titleEval.score * 1.25,
          bodyEval.score,
          catEval.score * 0.9,
          tagHit ? 88 : 0
        );
        bestScore = Math.round(weighted);
        if (tagHit && titleEval.score < 88) matchKind = 'tag';
        else if (titleEval.score >= bodyEval.score) matchKind = titleEval.matchKind;
        else matchKind = bodyEval.matchKind;
      }

      if (bestScore > 0) {
        if (mem.isPinned) bestScore += 8;
        results.push({
          uid: `memory-${mem.id}`,
          type: 'memory',
          id: mem.id,
          title: mem.title,
          subtitle: `${mem.category} · اهمیت ${mem.importance}${mem.isArchived ? ' · بایگانی‌شده' : ''}`,
          snippet: buildSnippet(mem.content, queryNorm),
          tags: mem.tags,
          score: bestScore,
          matchKind,
          updatedAt: mem.updatedAt,
          targetScreen: 'memories',
          metaLabel: 'حافظه هوشمند',
        });
      }
    }
  }

  // Module 1: Personal Info Vault
  if (allowedTypes.has('personal')) {
    for (const rec of listPersonalRecords()) {
      if (requiredTags.length && !hasTagMatch([rec.category])) continue;
      const combined = `${rec.fullName} ${rec.fieldKey} ${rec.isSensitive ? '' : rec.fieldValue} ${rec.category}`;
      const evalRes = !queryNorm
        ? { score: 40, matchKind: 'keyword' as const }
        : scoreField(combined, queryNorm, queryTokens, enableFuzzy);

      if (evalRes.score > 0) {
        results.push({
          uid: `personal-${rec.id}`,
          type: 'personal',
          id: rec.id,
          title: `${rec.fieldKey} — ${rec.fullName}`,
          subtitle: `اطلاعات شخصی · ${rec.category}`,
          snippet: rec.isSensitive ? 'مقدار محرمانه (نمایان در بخش حافظه شخصی)' : rec.fieldValue,
          tags: [rec.category],
          score: evalRes.score,
          matchKind: evalRes.matchKind,
          updatedAt: rec.updatedAt,
          targetScreen: 'memories',
          metaLabel: 'اطلاعات شخصی',
        });
      }
    }
  }

  // Module 2: Projects & Research
  if (allowedTypes.has('project')) {
    for (const proj of listProjects()) {
      if (!includeArchived && proj.status === 'archived') continue;
      if (!hasTagMatch(proj.tags)) continue;

      let bestScore = 0;
      let matchKind: UnifiedSearchResult['matchKind'] = 'keyword';

      if (!queryNorm) {
        bestScore = 55;
      } else {
        const titleEval = scoreField(proj.title, queryNorm, queryTokens, enableFuzzy);
        const descEval = scoreField(proj.description, queryNorm, queryTokens, enableFuzzy);
        const pathEval = scoreField(proj.folderPath, queryNorm, queryTokens, false);
        const tagHit = proj.tags.some((t) => normalizeDariText(t).includes(queryNorm));

        bestScore = Math.round(Math.max(titleEval.score * 1.25, descEval.score, pathEval.score, tagHit ? 86 : 0));
        matchKind = tagHit ? 'tag' : titleEval.score >= descEval.score ? titleEval.matchKind : descEval.matchKind;
      }

      if (bestScore > 0) {
        results.push({
          uid: `project-${proj.id}`,
          type: 'project',
          id: proj.id,
          title: proj.title,
          subtitle: `پیشرفت ${proj.progress}% · ${proj.documentCount ?? 0} سند متصل`,
          snippet: buildSnippet(proj.description || proj.folderPath, queryNorm),
          tags: proj.tags,
          score: bestScore,
          matchKind,
          updatedAt: proj.updatedAt,
          targetScreen: 'projects',
          metaLabel: 'پروژه و پژوهش',
        });
      }
    }
  }

  // Module 2: Document Library (also searches SHA-256 hash prefix & file path)
  if (allowedTypes.has('document')) {
    for (const doc of listDocuments(includeArchived)) {
      if (!hasTagMatch(doc.tags)) continue;

      let bestScore = 0;
      let matchKind: UnifiedSearchResult['matchKind'] = 'keyword';

      if (!queryNorm) {
        bestScore = 52;
      } else {
        const titleEval = scoreField(doc.title, queryNorm, queryTokens, enableFuzzy);
        const fileEval = scoreField(`${doc.fileName} ${doc.relativePath}`, queryNorm, queryTokens, enableFuzzy);
        const noteEval = scoreField(`${doc.notes} ${doc.projectTitle ?? ''}`, queryNorm, queryTokens, enableFuzzy);
        const hashHit = doc.sha256Hash.toLowerCase().includes(queryNorm);
        const tagHit = doc.tags.some((t) => normalizeDariText(t).includes(queryNorm));

        bestScore = Math.round(
          Math.max(titleEval.score * 1.2, fileEval.score * 1.1, noteEval.score, hashHit ? 110 : 0, tagHit ? 85 : 0)
        );
        matchKind = hashHit
          ? 'exact'
          : tagHit
          ? 'tag'
          : titleEval.score >= fileEval.score
          ? titleEval.matchKind
          : fileEval.matchKind;
      }

      if (bestScore > 0) {
        results.push({
          uid: `document-${doc.id}`,
          type: 'document',
          id: doc.id,
          title: doc.title,
          subtitle: `${doc.fileName}${doc.projectTitle ? ` · ${doc.projectTitle}` : ''}`,
          snippet: doc.notes || doc.relativePath || `SHA-256: ${doc.sha256Hash.slice(0, 16)}…`,
          tags: doc.tags,
          score: bestScore,
          matchKind,
          updatedAt: doc.updatedAt,
          targetScreen: 'documents',
          metaLabel: 'سند و فایل',
        });
      }
    }
  }

  // Module 3: Smart Archive & Intelligence Logs
  if (allowedTypes.has('archive')) {
    for (const log of listArchiveLogs(80)) {
      if (requiredTags.length) continue;
      const evalRes = !queryNorm
        ? { score: 30, matchKind: 'keyword' as const }
        : scoreField(`${log.targetRef} ${log.details} ${log.actionType}`, queryNorm, queryTokens, enableFuzzy);

      if (evalRes.score > 0) {
        results.push({
          uid: `archive-${log.id}`,
          type: 'archive',
          id: log.id,
          title: log.targetRef,
          subtitle: `سابقه آرشیف هوشمند · ${log.status}`,
          snippet: buildSnippet(log.details, queryNorm),
          tags: [],
          score: evalRes.score,
          matchKind: evalRes.matchKind,
          updatedAt: log.createdAt,
          targetScreen: 'archive',
          metaLabel: 'آرشیف هوشمند',
        });
      }
    }
  }

  if (options.sortBy === 'newest') {
    return results.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }
  return results.sort((a, b) => b.score - a.score || new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
}
