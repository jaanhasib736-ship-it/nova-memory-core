import initSqlJs, { type Database, type SqlJsStatic } from 'sql.js';
import type {
  ArchiveActionType,
  ArchiveLogRecord,
  DatabaseHealth,
  DocumentRecord,
  IntegrityStatus,
  MemoryCategory,
  MemoryHistoryRecord,
  MemoryImportance,
  MemoryRecord,
  PersonalInfoRecord,
  ProjectRecord,
  ProjectStatus,
  ProjectType,
  StorageSource,
} from '../types/nova';
import { loadPersistedSqliteBytes, savePersistedSqliteBytes } from './idbStorage';
import { CURRENT_SCHEMA_VERSION, NOVA_PACKAGE_ID, runSafeMigrations } from './schema';

let sqlModulePromise: Promise<SqlJsStatic> | null = null;
let dbInstance: Database | null = null;
let initPromise: Promise<Database> | null = null;
let lastSavedAt: string | null = null;
let recoveredOperationsCount = 0;

async function getSqlModule(): Promise<SqlJsStatic> {
  if (!sqlModulePromise) {
    const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
    sqlModulePromise = initSqlJs({
      locateFile: (file: string) => {
        if (isBrowser) {
          return `/${file}`;
        }
        return `node_modules/sql.js/dist/${file}`;
      },
    });
  }
  return sqlModulePromise;
}

function safeJsonParseArray(raw: unknown): string[] {
  if (typeof raw !== 'string') return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

function computeSimpleChecksum(text: string): string {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(12, '0');
}

export function autoCategorizeMemory(title: string, content: string): MemoryCategory {
  const combined = `${title} ${content}`.toLowerCase();
  if (/پژوهش|تحقیق|مقاله|کتاب|منبع|فصل|research|paper|study/.test(combined)) return 'پژوهش';
  if (/پروژه|کد|نسخه|معماری|برنامه|سامانه|api|sqlite|android/.test(combined)) return 'پروژه';
  if (/کلمه عبور|تذکره|پاسپورت|کارت|شماره|تلفن|آدرس|شخصی|هویت/.test(combined)) return 'شخصی';
  if (/بودجه|پرداخت|حساب|بانک|قرارداد|رسید|فاکتور|سند/.test(combined)) return 'مالی و اسناد';
  if (/ایده|طرح|پیشنهاد|خلاقیت|آینده|فکر/.test(combined)) return 'ایده';
  if (/تنظیم|سرور|کلید|رمز|امنیت|خطا|شبکه|فنی/.test(combined)) return 'فنی';
  return 'عمومی';
}

function recoverInterruptedOperations(db: Database): number {
  const res = db.exec("SELECT id, operation_name, started_at FROM operation_journal WHERE status = 'in_progress';");
  if (!res.length || !res[0].values.length) return 0;

  const now = new Date().toISOString();
  let count = 0;
  db.run('BEGIN TRANSACTION;');
  try {
    for (const row of res[0].values) {
      const opId = Number(row[0]);
      const opName = String(row[1]);
      db.run("UPDATE operation_journal SET status = 'recovered', completed_at = ? WHERE id = ?;", [now, opId]);
      db.run(
        'INSERT INTO archive_logs (action_type, target_ref, details, checksum, status, created_at) VALUES (?, ?, ?, ?, ?, ?);',
        [
          'recovery_checkpoint',
          opName,
          'بازیابی ایمن عملیات ناتمام پس از راه‌اندازی مجدد',
          computeSimpleChecksum(`${opId}:${opName}:${now}`),
          'recovered',
          now,
        ]
      );
      count++;
    }
    db.run('COMMIT;');
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }
  return count;
}

function seedStarterRecordsIfFresh(db: Database): void {
  const memCount = Number(db.exec('SELECT COUNT(*) FROM memories;')[0]?.values[0]?.[0] ?? 0);
  const projCount = Number(db.exec('SELECT COUNT(*) FROM projects;')[0]?.values[0]?.[0] ?? 0);
  const docCount = Number(db.exec('SELECT COUNT(*) FROM documents;')[0]?.values[0]?.[0] ?? 0);
  if (memCount > 0 || projCount > 0 || docCount > 0) {
    return;
  }

  const now = Date.now();
  const daysAgo = (d: number) => new Date(now - d * 86400_000).toISOString();

  db.run('BEGIN TRANSACTION;');
  try {
    // Starter Project Records (Module 2)
    db.run(
      `INSERT INTO projects (title, description, project_type, status, progress, tags, folder_path, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        'معماری هسته حافظه نووا نسخه ۳',
        'طراحی و پیاده‌سازی یکپارچه ماژول‌های حافظه هوشمند، مرکز اسناد و بهینه‌سازی حافظه موبایل برای گلکسی A52',
        'engineering',
        'active',
        88,
        JSON.stringify(['نووا', 'اندروید۱۴', 'SQLite', 'امنیت']),
        '/Documents/NovaCore/Architecture',
        daysAgo(14),
        daysAgo(1),
      ]
    );
    db.run(
      `INSERT INTO projects (title, description, project_type, status, progress, tags, folder_path, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        'پژوهش زبان‌شناسی محاسباتی فارسی دری',
        'تدوین قواعد نرمال‌سازی حروف، جستجوی فازی و ریشه‌یابی واژگان در اسناد علمی دری',
        'research',
        'active',
        64,
        JSON.stringify(['دری', 'پژوهش', 'جستجو', 'الگوریتم']),
        '/Documents/Research/DariNLP',
        daysAgo(28),
        daysAgo(3),
      ]
    );
    db.run(
      `INSERT INTO projects (title, description, project_type, status, progress, tags, folder_path, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        'کتابچه راهنمای رمزنگاری و حفاظت داده در موبایل',
        'مجموعه یادداشت‌ها و استانداردهای Android Keystore، AES-256-GCM و احراز هویت بایومتریک',
        'book',
        'review',
        92,
        JSON.stringify(['کتاب', 'رمزنگاری', 'AES-GCM', 'کلید']),
        '/Documents/Books/MobileSecurity',
        daysAgo(45),
        daysAgo(7),
      ]
    );

    // Starter Memory Records (Module 1)
    const memoriesSeed: Array<[string, string, MemoryCategory, string[], MemoryImportance, boolean, boolean, number]> = [
      [
        'اصل حفاظت از فایل‌های شخصی کاربر',
        'هیچ فایل شخصی نباید بدون پشتیبان‌گیری تاییدشده و چک‌سام SHA-256 حذف شود. انتقال به آرشیف همیشه قابل بازیابی است.',
        'فنی',
        ['امنیت', 'آرشیف', 'اصول'],
        'حیاتی',
        true,
        false,
        2,
      ],
      [
        'یادداشت جلسه معماری جستجوی یکپارچه',
        'جستجوی یکپارچه باید همزمان حافظه‌ها، اطلاعات شخصی، پروژه‌ها، اسناد و سوابق آرشیف را با نرمال‌سازی حروف دری (ی/ي و ک/ك) جستجو کند.',
        'پروژه',
        ['جستجو', 'دری', 'نووا'],
        'مهم',
        true,
        false,
        4,
      ],
      [
        'مرجع کتاب ساختارهای داده پایدار',
        'فصل چهارم درباره درخت‌های B-Tree در SQLite و روش VACUUM بدون قفل شدن طولانی‌مدت در دستگاه‌های اندرویدی.',
        'پژوهش',
        ['کتاب', 'SQLite', 'پژوهش'],
        'عادی',
        false,
        false,
        18,
      ],
      [
        'ایده همگام‌سازی آفلاین با کدهای QR رمزنگاری‌شده',
        'برای انتقال کلید یا یادداشت‌های کوتاه بین دو دستگاه بدون اینترنت می‌توان از بسته‌های رمزنگاری‌شده AES-GCM استفاده کرد.',
        'ایده',
        ['ایده', 'آفلاین', 'رمزنگاری'],
        'عادی',
        false,
        false,
        42,
      ],
    ];

    for (const [title, content, category, tags, importance, pinned, archived, age] of memoriesSeed) {
      const ts = daysAgo(age);
      db.run(
        `INSERT INTO memories (title, content, category, tags, importance, language, is_pinned, is_archived, checksum, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 'fa-AF', ?, ?, ?, ?, ?);`,
        [
          title,
          content,
          category,
          JSON.stringify(tags),
          importance,
          pinned ? 1 : 0,
          archived ? 1 : 0,
          computeSimpleChecksum(`${title}:${content}`),
          ts,
          ts,
        ]
      );
    }

    // Personal Info Record (Module 1)
    db.run(
      `INSERT INTO personal_records (full_name, field_key, field_value, category, is_sensitive, updated_at)
       VALUES (?, ?, ?, ?, ?, ?);`,
      ['حسیب‌الرحمن صاحب‌زاده', 'دستگاه هدف', 'Samsung Galaxy A52 — Android 14', 'مشخصات فنی', 0, daysAgo(1)]
    );
    db.run(
      `INSERT INTO personal_records (full_name, field_key, field_value, category, is_sensitive, updated_at)
       VALUES (?, ?, ?, ?, ?, ?);`,
      ['حسیب‌الرحمن صاحب‌زاده', 'شناسه بسته اندروید', NOVA_PACKAGE_ID, 'توسعه', 0, daysAgo(1)]
    );

    // Starter Document Reference Records (Module 2) — referencing local logical paths (no mock files)
    db.run(
      `INSERT INTO documents (project_id, title, file_name, relative_path, mime_type, size_bytes, sha256_hash, storage_source, uri_reference, integrity_status, last_verified_at, is_archived, tags, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        1,
        'سند معماری یکپارچه هسته نووا',
        'nova_core_v3_spec.pdf',
        '/Documents/NovaCore/Architecture/nova_core_v3_spec.pdf',
        'application/pdf',
        2458624,
        'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        'saf_tree',
        'content://com.android.externalstorage.documents/tree/primary%3ADocuments%2FNovaCore',
        'verified',
        daysAgo(1),
        0,
        JSON.stringify(['معماری', 'PDF', 'نووا']),
        'مشخصات پایگاه‌داده و رابط SAF بدون کپی اضافی',
        daysAgo(12),
        daysAgo(1),
      ]
    );
    db.run(
      `INSERT INTO documents (project_id, title, file_name, relative_path, mime_type, size_bytes, sha256_hash, storage_source, uri_reference, integrity_status, last_verified_at, is_archived, tags, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        2,
        'پیکره واژگان استاندارد دری',
        'dari_lexicon_corpus.json',
        '/Documents/Research/DariNLP/dari_lexicon_corpus.json',
        'application/json',
        12582912,
        '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
        'saf_tree',
        'content://com.android.externalstorage.documents/tree/primary%3ADocuments%2FResearch',
        'verified',
        daysAgo(3),
        0,
        JSON.stringify(['دری', 'پیکره', 'پژوهش']),
        'فایل حجیم پیکره واژگانی برای جستجوی هوشمند',
        daysAgo(35),
        daysAgo(3),
      ]
    );

    db.run(
      `INSERT INTO archive_logs (action_type, target_ref, details, checksum, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?);`,
      [
        'integrity_scan',
        'سیستم هسته نووا V3',
        'مهاجرت ایمن پایگاه‌داده SQLite نسخه ۳ و تایید سلامت جداول اولیه',
        computeSimpleChecksum('init_v3'),
        'verified',
        daysAgo(0),
      ]
    );

    db.run('COMMIT;');
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }
}

export async function persistDatabase(): Promise<void> {
  if (!dbInstance) return;
  const exported = dbInstance.export();
  lastSavedAt = new Date().toISOString();
  await savePersistedSqliteBytes(exported);
}

export async function initializeDatabase(options?: { skipIdb?: boolean; seedIfEmpty?: boolean }): Promise<Database> {
  if (dbInstance) return dbInstance;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const SQL = await getSqlModule();
    const persisted = options?.skipIdb ? null : await loadPersistedSqliteBytes();
    const db = persisted ? new SQL.Database(persisted) : new SQL.Database();
    runSafeMigrations(db);
    recoveredOperationsCount = recoverInterruptedOperations(db);
    if (options?.seedIfEmpty !== false && !persisted) {
      seedStarterRecordsIfFresh(db);
    }
    dbInstance = db;
    if (!options?.skipIdb) {
      await persistDatabase();
    }
    return db;
  })();

  try {
    return await initPromise;
  } finally {
    initPromise = null;
  }
}

/**
 * Allows test suites or backup restoration to mount a specific SQLite buffer cleanly.
 */
export async function resetOrMountDatabaseForTesting(bytes?: Uint8Array): Promise<Database> {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
  initPromise = null;
  const SQL = await getSqlModule();
  const db = bytes ? new SQL.Database(bytes) : new SQL.Database();
  runSafeMigrations(db);
  recoveredOperationsCount = recoverInterruptedOperations(db);
  dbInstance = db;
  return db;
}

function getDbSync(): Database {
  if (!dbInstance) {
    throw new Error('پایگاه‌داده هنوز مقداردهی نشده است');
  }
  return dbInstance;
}

// ---------- MODULE 1: SMART MEMORY CRUD & HISTORY ----------

export function listMemories(includeArchived = true): MemoryRecord[] {
  const db = getDbSync();
  const query = includeArchived
    ? 'SELECT * FROM memories ORDER BY is_pinned DESC, updated_at DESC;'
    : 'SELECT * FROM memories WHERE is_archived = 0 ORDER BY is_pinned DESC, updated_at DESC;';
  const res = db.exec(query);
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      title: String(obj.title),
      content: String(obj.content),
      category: String(obj.category) as MemoryCategory,
      tags: safeJsonParseArray(obj.tags),
      importance: String(obj.importance) as MemoryImportance,
      language: (String(obj.language) || 'fa-AF') as 'fa-AF' | 'fa' | 'en',
      isPinned: Number(obj.is_pinned) === 1,
      isArchived: Number(obj.is_archived) === 1,
      checksum: String(obj.checksum ?? ''),
      createdAt: String(obj.created_at),
      updatedAt: String(obj.updated_at),
    };
  });
}

export async function createMemory(input: {
  title: string;
  content: string;
  category?: MemoryCategory;
  tags?: string[];
  importance?: MemoryImportance;
  language?: 'fa-AF' | 'fa' | 'en';
  isPinned?: boolean;
}): Promise<MemoryRecord> {
  const db = getDbSync();
  const now = new Date().toISOString();
  const category = input.category ?? autoCategorizeMemory(input.title, input.content);
  const tags = input.tags ?? [];
  const importance = input.importance ?? 'عادی';
  const language = input.language ?? 'fa-AF';
  const checksum = computeSimpleChecksum(`${input.title}:${input.content}:${now}`);

  db.run(
    `INSERT INTO memories (title, content, category, tags, importance, language, is_pinned, is_archived, checksum, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?);`,
    [
      input.title.trim(),
      input.content.trim(),
      category,
      JSON.stringify(tags),
      importance,
      language,
      input.isPinned ? 1 : 0,
      checksum,
      now,
      now,
    ]
  );

  const idRes = db.exec('SELECT last_insert_rowid();');
  const id = Number(idRes[0].values[0][0]);
  await persistDatabase();
  return listMemories(true).find((m) => m.id === id)!;
}

export async function updateMemory(
  id: number,
  updates: {
    title?: string;
    content?: string;
    category?: MemoryCategory;
    tags?: string[];
    importance?: MemoryImportance;
    isPinned?: boolean;
    isArchived?: boolean;
    changeNote?: string;
  }
): Promise<MemoryRecord> {
  const db = getDbSync();
  const existing = listMemories(true).find((m) => m.id === id);
  if (!existing) throw new Error('حافظه مورد نظر یافت نشد');

  const now = new Date().toISOString();
  const nextTitle = updates.title !== undefined ? updates.title.trim() : existing.title;
  const nextContent = updates.content !== undefined ? updates.content.trim() : existing.content;
  const nextCategory = updates.category ?? existing.category;
  const nextTags = updates.tags ?? existing.tags;
  const nextImportance = updates.importance ?? existing.importance;
  const nextPinned = updates.isPinned !== undefined ? updates.isPinned : existing.isPinned;
  const nextArchived = updates.isArchived !== undefined ? updates.isArchived : existing.isArchived;
  const nextChecksum = computeSimpleChecksum(`${nextTitle}:${nextContent}:${now}`);

  db.run('BEGIN TRANSACTION;');
  try {
    // Save immutable edit history whenever title/content/category/tags change
    if (
      nextTitle !== existing.title ||
      nextContent !== existing.content ||
      nextCategory !== existing.category ||
      JSON.stringify(nextTags) !== JSON.stringify(existing.tags)
    ) {
      db.run(
        `INSERT INTO memory_history (memory_id, previous_title, previous_content, previous_category, previous_tags, change_note, edited_at)
         VALUES (?, ?, ?, ?, ?, ?, ?);`,
        [
          id,
          existing.title,
          existing.content,
          existing.category,
          JSON.stringify(existing.tags),
          updates.changeNote ?? 'ویرایش رکورد حافظه',
          now,
        ]
      );
    }

    db.run(
      `UPDATE memories
       SET title = ?, content = ?, category = ?, tags = ?, importance = ?, is_pinned = ?, is_archived = ?, checksum = ?, updated_at = ?
       WHERE id = ?;`,
      [
        nextTitle,
        nextContent,
        nextCategory,
        JSON.stringify(nextTags),
        nextImportance,
        nextPinned ? 1 : 0,
        nextArchived ? 1 : 0,
        nextChecksum,
        now,
        id,
      ]
    );
    db.run('COMMIT;');
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }

  await persistDatabase();
  return listMemories(true).find((m) => m.id === id)!;
}

export async function deleteMemory(id: number): Promise<void> {
  const db = getDbSync();
  db.run('DELETE FROM memories WHERE id = ?;', [id]);
  await persistDatabase();
}

export function getMemoryHistory(memoryId: number): MemoryHistoryRecord[] {
  const db = getDbSync();
  const res = db.exec(
    `SELECT * FROM memory_history WHERE memory_id = ${Number(memoryId)} ORDER BY edited_at DESC, id DESC;`
  );
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      memoryId: Number(obj.memory_id),
      previousTitle: String(obj.previous_title),
      previousContent: String(obj.previous_content),
      previousCategory: String(obj.previous_category),
      previousTags: safeJsonParseArray(obj.previous_tags),
      changeNote: String(obj.change_note),
      editedAt: String(obj.edited_at),
    };
  });
}

// ---------- MODULE 1: PERSONAL INFORMATION MANAGEMENT ----------

export function listPersonalRecords(): PersonalInfoRecord[] {
  const db = getDbSync();
  const res = db.exec('SELECT * FROM personal_records ORDER BY updated_at DESC, id DESC;');
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      fullName: String(obj.full_name),
      fieldKey: String(obj.field_key),
      fieldValue: String(obj.field_value),
      category: String(obj.category),
      isSensitive: Number(obj.is_sensitive) === 1,
      updatedAt: String(obj.updated_at),
    };
  });
}

export async function upsertPersonalRecord(input: {
  id?: number;
  fullName: string;
  fieldKey: string;
  fieldValue: string;
  category: string;
  isSensitive: boolean;
}): Promise<PersonalInfoRecord> {
  const db = getDbSync();
  const now = new Date().toISOString();
  if (input.id) {
    db.run(
      `UPDATE personal_records SET full_name = ?, field_key = ?, field_value = ?, category = ?, is_sensitive = ?, updated_at = ? WHERE id = ?;`,
      [input.fullName, input.fieldKey, input.fieldValue, input.category, input.isSensitive ? 1 : 0, now, input.id]
    );
    await persistDatabase();
    return listPersonalRecords().find((r) => r.id === input.id)!;
  }
  db.run(
    `INSERT INTO personal_records (full_name, field_key, field_value, category, is_sensitive, updated_at)
     VALUES (?, ?, ?, ?, ?, ?);`,
    [input.fullName, input.fieldKey, input.fieldValue, input.category, input.isSensitive ? 1 : 0, now]
  );
  const id = Number(db.exec('SELECT last_insert_rowid();')[0].values[0][0]);
  await persistDatabase();
  return listPersonalRecords().find((r) => r.id === id)!;
}

export async function deletePersonalRecord(id: number): Promise<void> {
  const db = getDbSync();
  db.run('DELETE FROM personal_records WHERE id = ?;', [id]);
  await persistDatabase();
}

// ---------- MODULE 2: PROJECTS & RESEARCH MANAGEMENT ----------

export function listProjects(): ProjectRecord[] {
  const db = getDbSync();
  const res = db.exec(`
    SELECT p.*, COUNT(d.id) AS doc_count
    FROM projects p
    LEFT JOIN documents d ON d.project_id = p.id
    GROUP BY p.id
    ORDER BY p.updated_at DESC, p.id DESC;
  `);
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      title: String(obj.title),
      description: String(obj.description),
      projectType: String(obj.project_type) as ProjectType,
      status: String(obj.status) as ProjectStatus,
      progress: Number(obj.progress),
      tags: safeJsonParseArray(obj.tags),
      folderPath: String(obj.folder_path ?? ''),
      documentCount: Number(obj.doc_count ?? 0),
      createdAt: String(obj.created_at),
      updatedAt: String(obj.updated_at),
    };
  });
}

export async function createProject(input: {
  title: string;
  description: string;
  projectType: ProjectType;
  status?: ProjectStatus;
  progress?: number;
  tags?: string[];
  folderPath?: string;
}): Promise<ProjectRecord> {
  const db = getDbSync();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO projects (title, description, project_type, status, progress, tags, folder_path, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`,
    [
      input.title.trim(),
      input.description.trim(),
      input.projectType,
      input.status ?? 'active',
      Math.max(0, Math.min(100, input.progress ?? 0)),
      JSON.stringify(input.tags ?? []),
      input.folderPath ?? '',
      now,
      now,
    ]
  );
  const id = Number(db.exec('SELECT last_insert_rowid();')[0].values[0][0]);
  await persistDatabase();
  return listProjects().find((p) => p.id === id)!;
}

export async function updateProject(
  id: number,
  updates: Partial<{
    title: string;
    description: string;
    projectType: ProjectType;
    status: ProjectStatus;
    progress: number;
    tags: string[];
    folderPath: string;
  }>
): Promise<ProjectRecord> {
  const db = getDbSync();
  const existing = listProjects().find((p) => p.id === id);
  if (!existing) throw new Error('پروژه یافت نشد');
  const now = new Date().toISOString();
  db.run(
    `UPDATE projects SET title = ?, description = ?, project_type = ?, status = ?, progress = ?, tags = ?, folder_path = ?, updated_at = ? WHERE id = ?;`,
    [
      updates.title ?? existing.title,
      updates.description ?? existing.description,
      updates.projectType ?? existing.projectType,
      updates.status ?? existing.status,
      updates.progress !== undefined ? Math.max(0, Math.min(100, updates.progress)) : existing.progress,
      JSON.stringify(updates.tags ?? existing.tags),
      updates.folderPath ?? existing.folderPath,
      now,
      id,
    ]
  );
  await persistDatabase();
  return listProjects().find((p) => p.id === id)!;
}

export async function deleteProject(id: number): Promise<void> {
  const db = getDbSync();
  db.run('DELETE FROM projects WHERE id = ?;', [id]);
  await persistDatabase();
}

// ---------- MODULE 2: DOCUMENT CENTER & INTEGRITY ----------

export function listDocuments(includeArchived = true): DocumentRecord[] {
  const db = getDbSync();
  const where = includeArchived ? '' : 'WHERE d.is_archived = 0';
  const res = db.exec(`
    SELECT d.*, p.title AS project_title
    FROM documents d
    LEFT JOIN projects p ON d.project_id = p.id
    ${where}
    ORDER BY d.updated_at DESC, d.id DESC;
  `);
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      projectId: obj.project_id !== null ? Number(obj.project_id) : null,
      projectTitle: obj.project_title ? String(obj.project_title) : undefined,
      title: String(obj.title),
      fileName: String(obj.file_name),
      relativePath: String(obj.relative_path ?? ''),
      mimeType: String(obj.mime_type ?? 'application/octet-stream'),
      sizeBytes: Number(obj.size_bytes ?? 0),
      sha256Hash: String(obj.sha256_hash),
      storageSource: String(obj.storage_source) as StorageSource,
      uriReference: String(obj.uri_reference ?? ''),
      integrityStatus: String(obj.integrity_status) as IntegrityStatus,
      lastVerifiedAt: obj.last_verified_at ? String(obj.last_verified_at) : null,
      isArchived: Number(obj.is_archived) === 1,
      tags: safeJsonParseArray(obj.tags),
      notes: String(obj.notes ?? ''),
      createdAt: String(obj.created_at),
      updatedAt: String(obj.updated_at),
    };
  });
}

export async function registerDocument(input: {
  projectId?: number | null;
  title: string;
  fileName: string;
  relativePath: string;
  mimeType: string;
  sizeBytes: number;
  sha256Hash: string;
  storageSource: StorageSource;
  uriReference: string;
  tags?: string[];
  notes?: string;
}): Promise<{ document: DocumentRecord; duplicateOf: DocumentRecord | null }> {
  const db = getDbSync();
  const now = new Date().toISOString();

  // Check for existing duplicate SHA-256 hash without blocking registration unless identical path
  const existingDocs = listDocuments(true);
  const duplicateOf = existingDocs.find((d) => d.sha256Hash === input.sha256Hash) ?? null;

  db.run(
    `INSERT INTO documents (
      project_id, title, file_name, relative_path, mime_type, size_bytes,
      sha256_hash, storage_source, uri_reference, integrity_status, last_verified_at,
      is_archived, tags, notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'verified', ?, 0, ?, ?, ?, ?);`,
    [
      input.projectId ?? null,
      input.title.trim(),
      input.fileName,
      input.relativePath,
      input.mimeType || 'application/octet-stream',
      input.sizeBytes,
      input.sha256Hash,
      input.storageSource,
      input.uriReference,
      now,
      JSON.stringify(input.tags ?? []),
      input.notes ?? '',
      now,
      now,
    ]
  );
  const id = Number(db.exec('SELECT last_insert_rowid();')[0].values[0][0]);
  await persistDatabase();
  return {
    document: listDocuments(true).find((d) => d.id === id)!,
    duplicateOf,
  };
}

export async function updateDocument(
  id: number,
  updates: Partial<{
    projectId: number | null;
    title: string;
    integrityStatus: IntegrityStatus;
    lastVerifiedAt: string;
    isArchived: boolean;
    tags: string[];
    notes: string;
  }>
): Promise<DocumentRecord> {
  const db = getDbSync();
  const existing = listDocuments(true).find((d) => d.id === id);
  if (!existing) throw new Error('سند یافت نشد');
  const now = new Date().toISOString();
  db.run(
    `UPDATE documents
     SET project_id = ?, title = ?, integrity_status = ?, last_verified_at = ?, is_archived = ?, tags = ?, notes = ?, updated_at = ?
     WHERE id = ?;`,
    [
      updates.projectId !== undefined ? updates.projectId : existing.projectId,
      updates.title ?? existing.title,
      updates.integrityStatus ?? existing.integrityStatus,
      updates.lastVerifiedAt ?? existing.lastVerifiedAt,
      updates.isArchived !== undefined ? (updates.isArchived ? 1 : 0) : existing.isArchived ? 1 : 0,
      JSON.stringify(updates.tags ?? existing.tags),
      updates.notes ?? existing.notes,
      now,
      id,
    ]
  );
  await persistDatabase();
  return listDocuments(true).find((d) => d.id === id)!;
}

export async function removeDocumentReference(id: number): Promise<void> {
  const db = getDbSync();
  // Removes only the SQLite metadata reference; never deletes user's personal storage file.
  db.run('DELETE FROM documents WHERE id = ?;', [id]);
  await persistDatabase();
}

// ---------- MODULE 3: ARCHIVE LOGS, OPERATION JOURNAL & SETTINGS ----------

export function listArchiveLogs(limit = 100): ArchiveLogRecord[] {
  const db = getDbSync();
  const res = db.exec(`SELECT * FROM archive_logs ORDER BY created_at DESC, id DESC LIMIT ${Number(limit)};`);
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((c, i) => (obj[c] = row[i]));
    return {
      id: Number(obj.id),
      actionType: String(obj.action_type) as ArchiveActionType,
      targetRef: String(obj.target_ref),
      details: String(obj.details),
      checksum: String(obj.checksum),
      status: String(obj.status) as ArchiveLogRecord['status'],
      createdAt: String(obj.created_at),
    };
  });
}

export async function logArchiveAction(input: {
  actionType: ArchiveActionType;
  targetRef: string;
  details: string;
  checksum?: string;
  status?: ArchiveLogRecord['status'];
}): Promise<void> {
  const db = getDbSync();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO archive_logs (action_type, target_ref, details, checksum, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?);`,
    [
      input.actionType,
      input.targetRef,
      input.details,
      input.checksum ?? computeSimpleChecksum(`${input.actionType}:${input.targetRef}:${now}`),
      input.status ?? 'completed',
      now,
    ]
  );
  await persistDatabase();
}

export function beginOperationJournal(operationName: string): number {
  const db = getDbSync();
  const now = new Date().toISOString();
  db.run("INSERT INTO operation_journal (operation_name, status, started_at) VALUES (?, 'in_progress', ?);", [
    operationName,
    now,
  ]);
  return Number(db.exec('SELECT last_insert_rowid();')[0].values[0][0]);
}

export function completeOperationJournal(journalId: number): void {
  const db = getDbSync();
  const now = new Date().toISOString();
  db.run("UPDATE operation_journal SET status = 'completed', completed_at = ? WHERE id = ?;", [now, journalId]);
}

export function getSetting(key: string, fallback = ''): string {
  const db = getDbSync();
  const stmt = db.prepare('SELECT value FROM security_settings WHERE key = ?;');
  stmt.bind([key]);
  const found = stmt.step() ? String(stmt.get()[0]) : fallback;
  stmt.free();
  return found;
}

export function getAllSettings(): Record<string, string> {
  const db = getDbSync();
  const res = db.exec('SELECT key, value FROM security_settings;');
  const map: Record<string, string> = {};
  if (!res.length) return map;
  for (const row of res[0].values) {
    map[String(row[0])] = String(row[1]);
  }
  return map;
}

export async function setSetting(key: string, value: string): Promise<void> {
  const db = getDbSync();
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO security_settings (key, value, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at;`,
    [key, value, now]
  );
  await persistDatabase();
}

// ---------- DATABASE HEALTH, BACKUP EXPORT & SAFE RESTORE ----------

export function exportDatabaseBytes(): Uint8Array {
  const db = getDbSync();
  return db.export();
}

export async function importDatabaseBytesSafely(rawBytes: Uint8Array): Promise<{
  restoredVersion: number;
  recordTotal: number;
}> {
  // Verify SQLite3 header signature ("SQLite format 3\0")
  const header = new TextDecoder().decode(rawBytes.slice(0, 15));
  if (header !== 'SQLite format 3') {
    throw new Error('فایل پشتیبان ساختار معتبر SQLite ندارد');
  }

  const SQL = await getSqlModule();
  const candidateDb = new SQL.Database(rawBytes);
  try {
    const check = candidateDb.exec('PRAGMA integrity_check;');
    const msg = String(check[0]?.values[0]?.[0] ?? 'unknown');
    if (msg.toLowerCase() !== 'ok') {
      throw new Error(`بررسی سلامت پایگاه‌داده ناموفق بود: ${msg}`);
    }

    // Run non-destructive migrations to ensure backward/forward compatibility
    const migration = runSafeMigrations(candidateDb);

    // Swap active instance safely only after validation succeeds
    if (dbInstance) {
      dbInstance.close();
    }
    dbInstance = candidateDb;
    await persistDatabase();

    const memCount = Number(candidateDb.exec('SELECT COUNT(*) FROM memories;')[0]?.values[0]?.[0] ?? 0);
    const projCount = Number(candidateDb.exec('SELECT COUNT(*) FROM projects;')[0]?.values[0]?.[0] ?? 0);
    const docCount = Number(candidateDb.exec('SELECT COUNT(*) FROM documents;')[0]?.values[0]?.[0] ?? 0);

    await logArchiveAction({
      actionType: 'backup_restored',
      targetRef: 'SQLite Database',
      details: `بازیابی تاییدشده پایگاه‌داده (نسخه ${migration.currentVersion}) با ${memCount + projCount + docCount} رکورد`,
      status: 'verified',
    });

    return {
      restoredVersion: migration.currentVersion,
      recordTotal: memCount + projCount + docCount,
    };
  } catch (err) {
    candidateDb.close();
    throw err;
  }
}

export async function runDatabaseMaintenance(): Promise<{ integrityMessage: string; sizeBefore: number; sizeAfter: number }> {
  const db = getDbSync();
  const sizeBefore = db.export().byteLength;
  const journalId = beginOperationJournal('db_maintenance_vacuum');
  try {
    const check = db.exec('PRAGMA integrity_check;');
    const integrityMessage = String(check[0]?.values[0]?.[0] ?? 'ok');
    db.run('VACUUM;');
    db.run('ANALYZE;');
    completeOperationJournal(journalId);
    const sizeAfter = db.export().byteLength;
    await logArchiveAction({
      actionType: 'db_vacuum',
      targetRef: 'SQLite Core',
      details: `بهینه‌سازی و فشرده‌سازی پایگاه‌داده (${sizeBefore} -> ${sizeAfter} بایت) · سلامت: ${integrityMessage}`,
      status: 'verified',
    });
    return { integrityMessage, sizeBefore, sizeAfter };
  } catch (err) {
    throw err;
  }
}

export function getDatabaseHealth(): DatabaseHealth {
  const db = getDbSync();
  const schemaRes = db.exec('PRAGMA user_version;');
  const schemaVersion = Number(schemaRes[0]?.values[0]?.[0] ?? CURRENT_SCHEMA_VERSION);
  const checkRes = db.exec('PRAGMA integrity_check;');
  const integrityMessage = String(checkRes[0]?.values[0]?.[0] ?? 'ok');

  const countOf = (table: string) => Number(db.exec(`SELECT COUNT(*) FROM ${table};`)[0]?.values[0]?.[0] ?? 0);

  return {
    schemaVersion,
    packageId: getSetting('package_id', NOVA_PACKAGE_ID),
    integrityOk: integrityMessage.toLowerCase() === 'ok',
    integrityMessage,
    dbSizeBytes: db.export().byteLength,
    counts: {
      memories: countOf('memories'),
      memoryHistory: countOf('memory_history'),
      personalRecords: countOf('personal_records'),
      projects: countOf('projects'),
      documents: countOf('documents'),
      archiveLogs: countOf('archive_logs'),
    },
    recoveredOperations: recoveredOperationsCount,
    lastSavedAt,
  };
}
