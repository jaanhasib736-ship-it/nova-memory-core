import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  FilePlus2,
  FolderPlus,
  Link2,
  Search,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import {
  listDocuments,
  listProjects,
  removeDocumentReference,
  updateDocument,
} from '../../db/sqliteEngine';
import { formatBytesDari, formatDateDari, toPersianDigits } from '../../services/androidBridge';
import { normalizeDariText } from '../../services/searchService';
import {
  getLinkedSafFolders,
  isSafDirectoryPickerSupported,
  pickAndRegisterSafDirectory,
  registerFilesFromPicker,
  verifyDocumentWithFile,
} from '../../services/storageService';
import type { DocumentRecord, IntegrityStatus } from '../../types/nova';

interface DocumentsScreenProps {
  highlightedId?: number;
  onRefresh: () => Promise<void>;
}

export const DocumentsScreen: React.FC<DocumentsScreenProps> = ({ highlightedId, onRefresh }) => {
  const [selectedProjectId, setSelectedProjectId] = useState<number | 'all'>('all');
  const [targetProjectForUpload, setTargetProjectForUpload] = useState<number | ''>('');
  const [integrityFilter, setIntegrityFilter] = useState<'all' | IntegrityStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [verifyingDocId, setVerifyingDocId] = useState<number | null>(null);
  const [safFoldersCount, setSafFoldersCount] = useState(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const dirInputRef = useRef<HTMLInputElement | null>(null);
  const verifyInputRef = useRef<HTMLInputElement | null>(null);

  const documents = listDocuments(true);
  const projects = listProjects();

  useEffect(() => {
    getLinkedSafFolders().then((f) => setSafFoldersCount(f.length));
  }, [documents.length]);

  useEffect(() => {
    if (highlightedId) {
      const target = documents.find((d) => d.id === highlightedId);
      if (target) {
        setSearchQuery(target.fileName);
      }
    }
  }, [highlightedId]);

  const handleSafFolderPick = async () => {
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const res = await pickAndRegisterSafDirectory(
        targetProjectForUpload === '' ? null : Number(targetProjectForUpload)
      );
      setStatusMessage(
        `پوشه «${res.folderName}» ثبت شد: ${toPersianDigits(res.filesCount)} فایل با SHA-256 ثبت گردید` +
          (res.duplicatesCount > 0 ? ` (${toPersianDigits(res.duplicatesCount)} فایل تکراری شناسایی شد).` : '.')
      );
      await onRefresh();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'خطا در دسترسی به پوشه SAF');
    }
  };

  const handleFilesSelected = async (fileList: FileList | null, source: 'file_picker' | 'saf_tree') => {
    if (!fileList || fileList.length === 0) return;
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const files = Array.from(fileList);
      const res = await registerFilesFromPicker(files, {
        projectId: targetProjectForUpload === '' ? null : Number(targetProjectForUpload),
        storageSource: source,
        tags: [source === 'saf_tree' ? 'پوشه' : 'فایل'],
      });
      const dupMsg =
        res.duplicatesDetected.length > 0
          ? ` · هشدار: ${toPersianDigits(res.duplicatesDetected.length)} فایل تکراری (SHA-256 یکسان) شناسایی شد`
          : '';
      setStatusMessage(`${toPersianDigits(res.registered.length)} سند بدون کپی‌برداری اضافه ثبت شد${dupMsg}`);
      await onRefresh();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'خطا در ثبت اسناد');
    }
  };

  const handleVerifyFileChosen = async (fileList: FileList | null) => {
    if (!fileList || !fileList[0] || verifyingDocId === null) return;
    try {
      const res = await verifyDocumentWithFile(verifyingDocId, fileList[0]);
      if (res.matches) {
        setStatusMessage(`اصالت SHA-256 تایید شد (${res.computedHash.slice(0, 16)}…). فایل دستکاری نشده است.`);
      } else {
        setErrorMessage(
          `هشدار عدم تطابق SHA-256! هش فعلی فایل (${res.computedHash.slice(0, 12)}…) با مرجع ثبت‌شده (${res.expectedHash.slice(0, 12)}…) متفاوت است.`
        );
      }
      await onRefresh();
    } finally {
      setVerifyingDocId(null);
    }
  };

  const filteredDocs = documents.filter((d) => {
    if (selectedProjectId !== 'all' && d.projectId !== selectedProjectId) return false;
    if (integrityFilter !== 'all' && d.integrityStatus !== integrityFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = normalizeDariText(searchQuery);
    return (
      normalizeDariText(d.title).includes(q) ||
      normalizeDariText(d.fileName).includes(q) ||
      normalizeDariText(d.relativePath).includes(q) ||
      d.sha256Hash.toLowerCase().includes(q)
    );
  });

  // Detect duplicate hashes across all registered docs
  const hashCounts = new Map<string, number>();
  documents.forEach((d) => hashCounts.set(d.sha256Hash, (hashCounts.get(d.sha256Hash) ?? 0) + 1));

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100">ماژول ۲: کتابخانه اسناد و اصالت‌سنجی SHA-256</h1>
          <p className="text-xs text-slate-400 mt-1">
            ثبت اسناد از حافظه موبایل (SAF / File Picker) بدون تکثیر فایل · بررسی اصالت و کشف فایل‌های تکراری
          </p>
        </div>

        <div className="text-xs text-slate-400">
          پوشه‌های متصل SAF: <span className="text-emerald-300 font-semibold tabular-nums">{toPersianDigits(safFoldersCount)}</span>
        </div>
      </div>

      {/* Registration Toolbar */}
      <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-4 space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={targetProjectForUpload}
            onChange={(e) => setTargetProjectForUpload(e.target.value ? Number(e.target.value) : '')}
            className="min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
          >
            <option value="">بدون اتصال به پروژه (عمومی)</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                اتصال به: {p.title}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
          >
            <FilePlus2 className="h-4 w-4" />
            <span>ثبت فایل‌ها (محاسبه SHA-256)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (isSafDirectoryPickerSupported()) {
                void handleSafFolderPick();
              } else {
                dirInputRef.current?.click();
              }
            }}
            className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-sm font-medium text-amber-300 hover:bg-amber-500/20"
          >
            <FolderPlus className="h-4 w-4" />
            <span>ثبت پوشه (Android SAF)</span>
          </button>

          {/* Hidden Inputs */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              void handleFilesSelected(e.target.files, 'file_picker');
              e.target.value = '';
            }}
          />
          <input
            ref={dirInputRef}
            type="file"
            multiple
            // @ts-expect-error webkitdirectory is supported on Chromium/Android WebView
            webkitdirectory=""
            className="hidden"
            onChange={(e) => {
              void handleFilesSelected(e.target.files, 'saf_tree');
              e.target.value = '';
            }}
          />
          <input
            ref={verifyInputRef}
            type="file"
            className="hidden"
            onChange={(e) => {
              void handleVerifyFileChosen(e.target.files);
              e.target.value = '';
            }}
          />
        </div>

        {statusMessage && (
          <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-3.5 py-2.5 text-xs text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
            <span>{statusMessage}</span>
          </div>
        )}
        {errorMessage && (
          <div className="rounded-xl border border-rose-500/35 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-200 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Filter Row */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2 border-t border-slate-800/80">
          <div className="sm:col-span-6 relative">
            <Search className="h-4 w-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستوجو بر اساس نام فایل، مسیر یا پیشوند هش SHA-256..."
              className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#07101f] pr-10 pl-3 text-sm text-slate-100"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
              className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
            >
              <option value="all">همه پروژه‌ها</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-3">
            <select
              value={integrityFilter}
              onChange={(e) => setIntegrityFilter(e.target.value as 'all' | IntegrityStatus)}
              className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
            >
              <option value="all">همه وضعیت‌های اصالت</option>
              <option value="verified">تاییدشده</option>
              <option value="pending">در انتظار بررسی</option>
              <option value="mismatch">عدم تطابق هش</option>
            </select>
          </div>
        </div>
      </div>

      {/* Document Cards */}
      {filteredDocs.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-10 text-center text-sm text-slate-400">
          سندی با این مشخصات یافت نشد. برای ثبت اسناد روی «ثبت فایل‌ها» یا «ثبت پوشه» کلیک کنید.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredDocs.map((doc: DocumentRecord) => {
            const isDup = (hashCounts.get(doc.sha256Hash) ?? 0) > 1;
            const isHighlighted = highlightedId === doc.id;
            return (
              <div
                key={doc.id}
                className={`rounded-2xl border p-4 sm:p-5 transition-colors ${
                  isHighlighted
                    ? 'border-amber-400 bg-[#132540]'
                    : 'border-slate-800 bg-[#0d1b30] hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-bold text-slate-100">{doc.title}</h3>
                      {isDup && (
                        <span className="text-xs font-medium text-amber-300">
                          (تکراری با فایل دیگر)
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-400 flex flex-wrap items-center gap-2">
                      <span className="font-mono-tabular text-slate-300" dir="ltr">
                        {doc.fileName}
                      </span>
                      <span>·</span>
                      <span className="tabular-nums">{formatBytesDari(doc.sizeBytes)}</span>
                      <span>·</span>
                      <span
                        className={
                          doc.integrityStatus === 'verified'
                            ? 'text-emerald-400'
                            : doc.integrityStatus === 'mismatch'
                            ? 'text-rose-400'
                            : 'text-amber-300'
                        }
                      >
                        {doc.integrityStatus === 'verified'
                          ? 'اصالت SHA-256 تاییدشده'
                          : doc.integrityStatus === 'mismatch'
                          ? 'عدم تطابق هش'
                          : 'در انتظار تایید'}
                      </span>
                      {doc.isArchived && (
                        <>
                          <span>·</span>
                          <span className="text-amber-300">آرشیف‌شده</span>
                        </>
                      )}
                    </div>

                    <div className="text-[11px] font-mono-tabular text-slate-500 break-all" dir="ltr">
                      SHA-256: {doc.sha256Hash}
                    </div>
                    <div className="text-xs text-slate-400">
                      مسیر: <span dir="ltr" className="font-mono-tabular">{doc.relativePath || doc.uriReference}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <select
                      aria-label="اتصال به پروژه"
                      value={doc.projectId ?? ''}
                      onChange={async (e) => {
                        await updateDocument(doc.id, {
                          projectId: e.target.value ? Number(e.target.value) : null,
                        });
                        await onRefresh();
                      }}
                      className="min-h-[38px] rounded-lg border border-slate-700 bg-[#07101f] px-2.5 text-xs text-slate-200"
                    >
                      <option value="">بدون پروژه</option>
                      {projects.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.title}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => {
                        setVerifyingDocId(doc.id);
                        verifyInputRef.current?.click();
                      }}
                      className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 text-xs font-medium text-emerald-300 hover:bg-emerald-500/20"
                    >
                      <ShieldCheck className="h-3.5 w-3.5" />
                      <span>بررسی اصالت</span>
                    </button>

                    <button
                      type="button"
                      onClick={async () => {
                        await removeDocumentReference(doc.id);
                        await onRefresh();
                      }}
                      title="حذف فقط از فهرست مرجع (فایل اصلی روی گوشی دست‌نخورده می‌ماند)"
                      className="min-h-[38px] inline-flex items-center gap-1 rounded-lg px-2.5 text-xs text-slate-400 hover:bg-rose-500/10 hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>لغو ثبت</span>
                    </button>
                  </div>
                </div>

                {doc.lastVerifiedAt && (
                  <div className="mt-2 pt-2 border-t border-slate-800/70 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="inline-flex items-center gap-1">
                      <Link2 className="h-3 w-3" />
                      {doc.projectTitle ? `متصل به: ${doc.projectTitle}` : 'سند مستقل'}
                    </span>
                    <span className="tabular-nums">آخرین بررسی: {formatDateDari(doc.lastVerifiedAt)}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
