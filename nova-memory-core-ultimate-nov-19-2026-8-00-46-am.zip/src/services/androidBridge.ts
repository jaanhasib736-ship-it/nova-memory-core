export function toPersianDigits(value: string | number): string {
  const digits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(value).replace(/\d/g, (d) => digits[Number(d)]);
}

export function formatBytesDari(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '۰ بایت';
  const units = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت', 'ترابایت'];
  const idx = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / Math.pow(1024, idx);
  const formatted = idx === 0 ? Math.round(val).toString() : val.toFixed(val >= 100 ? 0 : 1);
  return `${toPersianDigits(formatted)} ${units[idx]}`;
}

export function formatDateDari(iso: string): string {
  try {
    const date = new Date(iso);
    return new Intl.DateTimeFormat('fa-AF', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  } catch {
    return iso;
  }
}

export interface AndroidRuntimeCapabilities {
  isNativeAndroidBridge: boolean;
  isFileSystemAccessSupported: boolean;
  isWebAuthnSupported: boolean;
  isPwaStandalone: boolean;
  userAgentSummary: string;
}

export function detectRuntimeCapabilities(): AndroidRuntimeCapabilities {
  const isBrowser = typeof window !== 'undefined';
  const isNativeAndroidBridge = isBrowser && Boolean(window.NovaAndroidBridge);
  const isFileSystemAccessSupported = isBrowser && typeof window.showDirectoryPicker === 'function';
  const isWebAuthnSupported = isBrowser && typeof window.PublicKeyCredential !== 'undefined';
  const isPwaStandalone =
    isBrowser &&
    (window.matchMedia('(display-mode: standalone)').matches ||
      Boolean((window.navigator as unknown as { standalone?: boolean }).standalone));

  return {
    isNativeAndroidBridge,
    isFileSystemAccessSupported,
    isWebAuthnSupported,
    isPwaStandalone,
    userAgentSummary: isBrowser ? navigator.userAgent : 'Node/Test Runtime',
  };
}
