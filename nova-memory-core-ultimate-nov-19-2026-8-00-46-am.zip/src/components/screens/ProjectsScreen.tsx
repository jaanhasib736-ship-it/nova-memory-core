import React, { useEffect, useState } from 'react';
import { BookOpen, Edit3, FolderOpen, Plus, Trash2, X } from 'lucide-react';
import {
  createProject,
  deleteProject,
  listDocuments,
  listProjects,
  updateProject,
} from '../../db/sqliteEngine';
import { formatBytesDari, formatDateDari, toPersianDigits } from '../../services/androidBridge';
import type { NavigationIntent, ProjectRecord, ProjectStatus, ProjectType } from '../../types/nova';

const PROJECT_TYPES: Array<{ id: ProjectType; label: string }> = [
  { id: 'research', label: 'پژوهش علمی' },
  { id: 'book', label: 'تالیف کتاب' },
  { id: 'engineering', label: 'پروژه مهندسی' },
  { id: 'personal', label: 'مدیریت شخصی' },
];

const PROJECT_STATUSES: Array<{ id: ProjectStatus; label: string }> = [
  { id: 'active', label: 'فعال' },
  { id: 'review', label: 'بازبینی' },
  { id: 'completed', label: 'تکمیل‌شده' },
  { id: 'archived', label: 'آرشیف' },
];

interface ProjectsScreenProps {
  highlightedId?: number;
  onRefresh: () => Promise<void>;
  onNavigateIntent: (intent: NavigationIntent) => void;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  highlightedId,
  onRefresh,
  onNavigateIntent,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | ProjectStatus>('all');
  const [selectedProject, setSelectedProject] = useState<ProjectRecord | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ProjectRecord | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectType, setProjectType] = useState<ProjectType>('research');
  const [status, setStatus] = useState<ProjectStatus>('active');
  const [progress, setProgress] = useState(25);
  const [tagsRaw, setTagsRaw] = useState('');
  const [folderPath, setFolderPath] = useState('');

  const projects = listProjects();
  const documents = listDocuments(true);

  useEffect(() => {
    if (highlightedId) {
      const target = listProjects().find((p) => p.id === highlightedId);
      if (target) setSelectedProject(target);
    }
  }, [highlightedId]);

  const openNew = () => {
    setEditing(null);
    setTitle('');
    setDescription('');
    setProjectType('research');
    setStatus('active');
    setProgress(10);
    setTagsRaw('');
    setFolderPath('/Documents/Projects/');
    setModalOpen(true);
  };

  const openEdit = (p: ProjectRecord) => {
    setEditing(p);
    setTitle(p.title);
    setDescription(p.description);
    setProjectType(p.projectType);
    setStatus(p.status);
    setProgress(p.progress);
    setTagsRaw(p.tags.join('، '));
    setFolderPath(p.folderPath);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const tags = tagsRaw
      .split(/[,،]+/)
      .map((s) => s.trim())
      .filter(Boolean);

    if (editing) {
      const updated = await updateProject(editing.id, {
        title,
        description,
        projectType,
        status,
        progress,
        tags,
        folderPath,
      });
      setSelectedProject(updated);
    } else {
      const created = await createProject({
        title,
        description,
        projectType,
        status,
        progress,
        tags,
        folderPath,
      });
      setSelectedProject(created);
    }
    setModalOpen(false);
    await onRefresh();
  };

  const filtered = projects.filter((p) => (statusFilter === 'all' ? true : p.status === statusFilter));
  const linkedDocs = selectedProject
    ? documents.filter((d) => d.projectId === selectedProject.id)
    : [];

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100">ماژول ۲: مدیریت پروژه‌ها، کتاب‌ها و پژوهش‌ها</h1>
          <p className="text-xs text-slate-400 mt-1">
            سازمان‌دهی کتاب‌ها، طرح‌های پژوهشی و اتصال مستقیم آن‌ها به اسناد تاییدشده در SQLite
          </p>
        </div>

        <button
          type="button"
          onClick={openNew}
          className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          <span>پروژه / کتاب جدید</span>
        </button>
      </div>

      {/* Status Segmented Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 bg-[#0d1b30] p-1.5 rounded-xl border border-slate-800 w-fit">
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            statusFilter === 'all' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          همه ({toPersianDigits(projects.length)})
        </button>
        {PROJECT_STATUSES.map((st) => (
          <button
            key={st.id}
            type="button"
            onClick={() => setStatusFilter(st.id)}
            className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === st.id ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
            }`}
          >
            {st.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Projects Grid */}
        <div className="lg:col-span-7 space-y-3">
          {filtered.length === 0 ? (
            <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-8 text-center text-sm text-slate-400">
              پروژه‌ای در این وضعیت ثبت نشده است.
            </div>
          ) : (
            filtered.map((proj) => {
              const isSelected = selectedProject?.id === proj.id || highlightedId === proj.id;
              const typeLabel = PROJECT_TYPES.find((t) => t.id === proj.projectType)?.label ?? proj.projectType;
              const statusLabel = PROJECT_STATUSES.find((s) => s.id === proj.status)?.label ?? proj.status;
              return (
                <div
                  key={proj.id}
                  onClick={() => setSelectedProject(proj)}
                  className={`cursor-pointer rounded-2xl border p-5 transition-colors ${
                    isSelected
                      ? 'border-emerald-500/60 bg-[#132540]'
                      : 'border-slate-800 bg-[#0d1b30] hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-100">{proj.title}</h3>
                      <div className="mt-1 text-xs text-slate-400 flex flex-wrap items-center gap-2">
                        <span className="text-amber-300">{typeLabel}</span>
                        <span>·</span>
                        <span>{statusLabel}</span>
                        <span>·</span>
                        <span className="tabular-nums">{toPersianDigits(proj.documentCount ?? 0)} سند متصل</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => openEdit(proj)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-emerald-300"
                        title="ویرایش پروژه"
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteProject(proj.id);
                          if (selectedProject?.id === proj.id) setSelectedProject(null);
                          await onRefresh();
                        }}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-rose-500/10 hover:text-rose-400"
                        title="حذف پروژه"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {proj.description && (
                    <p className="mt-2.5 text-sm text-slate-300 leading-relaxed line-clamp-2">
                      {proj.description}
                    </p>
                  )}

                  <div className="mt-4 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">پیشرفت پروژه</span>
                      <span className="font-semibold tabular-nums text-emerald-300">
                        {toPersianDigits(proj.progress)}٪
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-[#07101f] overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full transition-all"
                        style={{ width: `${proj.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Linked Documents & Detail Panel */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 h-fit space-y-4">
          {selectedProject ? (
            <>
              <div className="border-b border-slate-800 pb-3">
                <h2 className="text-base font-bold text-slate-100">{selectedProject.title}</h2>
                <div className="mt-1 flex items-center gap-2 text-xs text-slate-400 font-mono-tabular">
                  <FolderOpen className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                  <span className="truncate" dir="ltr">
                    {selectedProject.folderPath || '/Documents'}
                  </span>
                </div>
                <div className="mt-2 text-xs text-slate-400">
                  آخرین تغییر: {formatDateDari(selectedProject.updatedAt)}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-200">
                  اسناد متصل ({toPersianDigits(linkedDocs.length)})
                </h3>
                <button
                  type="button"
                  onClick={() => onNavigateIntent({ screen: 'documents' })}
                  className="text-xs font-medium text-emerald-400 hover:underline"
                >
                  ثبت / اتصال سند جدید
                </button>
              </div>

              {linkedDocs.length === 0 ? (
                <p className="text-xs text-slate-400 py-4">
                  هنوز سندی به این پروژه متصل نشده است. از بخش «کتابخانه اسناد» می‌توانید فایل‌ها را به این پروژه متصل کنید.
                </p>
              ) : (
                <div className="divide-y divide-slate-800">
                  {linkedDocs.map((doc) => (
                    <button
                      key={doc.id}
                      type="button"
                      onClick={() =>
                        onNavigateIntent({ screen: 'documents', selectedId: doc.id, selectedType: 'document' })
                      }
                      className="w-full py-3 text-right flex items-center justify-between gap-3 hover:bg-slate-800/30 rounded-lg px-2 transition-colors"
                    >
                      <div className="min-w-0 flex items-center gap-2.5">
                        <BookOpen className="h-4 w-4 text-emerald-400 shrink-0" />
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-slate-100 truncate">{doc.title}</div>
                          <div className="text-xs text-slate-400 truncate font-mono-tabular">{doc.fileName}</div>
                        </div>
                      </div>
                      <span className="text-xs text-slate-400 tabular-nums shrink-0">
                        {formatBytesDari(doc.sizeBytes)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="py-10 text-center text-sm text-slate-400">
              یک پروژه یا کتاب را از فهرست انتخاب کنید تا جزئیات و اسناد متصل آن نمایش داده شود.
            </div>
          )}
        </div>
      </div>

      {/* Create / Edit Project Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="w-full max-w-lg rounded-2xl border border-slate-700 bg-[#0d1b30] p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-slate-100">
                {editing ? 'ویرایش پروژه / کتاب' : 'ثبت پروژه یا اثر پژوهشی جدید'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3">
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="عنوان پروژه، کتاب یا پژوهش"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="شرح اهداف، فصل‌ها یا نکات کلیدی..."
                className="w-full rounded-xl border border-slate-700 bg-[#07101f] p-3.5 text-sm text-slate-100"
              />

              <div className="grid grid-cols-2 gap-3">
                <select
                  value={projectType}
                  onChange={(e) => setProjectType(e.target.value as ProjectType)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
                >
                  {PROJECT_TYPES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.label}
                    </option>
                  ))}
                </select>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ProjectStatus)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3 text-sm text-slate-100"
                >
                  {PROJECT_STATUSES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>میزان پیشرفت</span>
                  <span className="tabular-nums text-emerald-300">{toPersianDigits(progress)}٪</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={progress}
                  onChange={(e) => setProgress(Number(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <input
                type="text"
                value={folderPath}
                onChange={(e) => setFolderPath(e.target.value)}
                placeholder="مسیر پوشه روی حافظه (مثلاً /Documents/Research)"
                dir="ltr"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100 font-mono-tabular"
              />

              <input
                type="text"
                value={tagsRaw}
                onChange={(e) => setTagsRaw(e.target.value)}
                placeholder="برچسب‌ها (با کاما جدا کنید)"
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="min-h-[44px] px-4 rounded-xl border border-slate-700 text-sm text-slate-300"
              >
                لغو
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-xl bg-emerald-600 text-sm font-semibold text-white"
              >
                ذخیره پروژه
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
