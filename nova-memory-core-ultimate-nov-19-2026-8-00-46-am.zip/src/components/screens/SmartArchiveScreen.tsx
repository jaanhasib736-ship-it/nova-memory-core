import React, { useRef, useState } from 'react';
import {
  Archive,
  CheckCircle2,
  Download,
  Lock,
  RotateCcw,
  ShieldAlert,
  Upload,
} from 'lucide-react';
import {
  exportDatabaseBytes,
  importDatabaseBytesSafely,
  listArchiveLogs,
  listDocuments,
  listMemories,
  logArchiveAction,
  updateDocument,
  updateMemory,
} from '../../db/sqliteEngine';
import { formatBytesDari, formatDateDari, toPersianDigits } from '../../services/androidBridge';
import {
  createEncryptedDatabaseBackup,
  restoreEncryptedDatabaseBackup,
} from '../../services/cryptoService';
import { runSmartArchiveBatch } from '../../services/storageService';
import type { ArchiveSuggestion } from '../../types/nova';

interface SmartArchiveScreenProps {
  suggestions: ArchiveSuggestion[];
  onRefresh: () => Promise<void>;
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const SmartArchiveScreen: React.FC<SmartArchiveScreenProps> = ({ suggestions, onRefresh }) => {
  const [backupPassword, setBackupPassword] = useState('');
  const [restorePassword, setRestorePassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'suggestions' | 'archived' | 'logs'>('suggestions');

  const restoreEncryptedRef = useRef<HTMLInputElement | null>(null);
  const restoreSqliteRef = useRef<HTMLInputElement | null>(null);

  const archivedMemories = listMemories(true).filter((m) => m.isArchived);
  const archivedDocs = listDocuments(true).filter((d) => d.isArchived);
  const logs = listArchiveLogs(50);

  const handleRunSmartArchive = async () => {
    if (!suggestions.length) return;
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const count = await runSmartArchiveBatch(suggestions);
      setMessage(`${toPersianDigits(count)} مورد با موفقیت در آرشیف هوشمند سازمان‌دهی شد.`);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در آرشیف خودکار');
    } finally {
      setBusy(false);
    }
  };

  const handleEncryptedBackup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    if (backupPassword.length < 4) {
      setError('لطفاً یک رمز حداقل ۴ کاراکتری برای رمزنگاری AES-256-GCM وارد کنید.');
      return;
    }
    setBusy(true);
    try {
      const res = await createEncryptedDatabaseBackup(backupPassword);
      const stamp = new Date().toISOString().slice(0, 10);
      triggerDownload(new Blob([res.jsonString], { type: 'application/json' }), `nova-backup-${stamp}.novabak`);
      setMessage(
        `پشتیبان رمزنگاری‌شده AES-256-GCM ایجاد و دانلود شد (SHA-256: ${res.envelope.plaintextSha256.slice(0, 14)}…).`
      );
      setBackupPassword('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در ایجاد پشتیبان');
    } finally {
      setBusy(false);
    }
  };

  const handleRawSqliteExport = async () => {
    const bytes = exportDatabaseBytes();
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    const stamp = new Date().toISOString().slice(0, 10);
    triggerDownload(new Blob([copy.buffer], { type: 'application/x-sqlite3' }), `nova-memory-core-${stamp}.sqlite`);
    await logArchiveAction({
      actionType: 'backup_created',
      targetRef: 'Raw SQLite Export (.sqlite)',
      details: `خروجی مستقیم پایگاه‌داده SQLite (${bytes.byteLength} بایت)`,
      status: 'completed',
    });
    setMessage('فایل پایگاه‌داده SQLite با موفقیت ذخیره شد.');
    await onRefresh();
  };

  const handleEncryptedRestoreFile = async (files: FileList | null) => {
    if (!files || !files[0]) return;
    setError(null);
    setMessage(null);
    if (!restorePassword) {
      setError('ابتدا رمز فایل پشتیبان را در کادر بازیابی وارد کنید.');
      return;
    }
    setBusy(true);
    try {
      const text = await files[0].text();
      const res = await restoreEncryptedDatabaseBackup(text, restorePassword);
      setMessage(
        `بازیابی تاییدشده انجام شد! نسخه اسکیما: ${toPersianDigits(res.restoredVersion)} · مجموع رکوردها: ${toPersianDigits(res.recordTotal)}`
      );
      setRestorePassword('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'بازیابی ناموفق بود');
    } finally {
      setBusy(false);
    }
  };

  const handleRawSqliteRestore = async (files: FileList | null) => {
    if (!files || !files[0]) return;
    setError(null);
    setMessage(null);
    setBusy(true);
    try {
      const buf = await files[0].arrayBuffer();
      const res = await importDatabaseBytesSafely(new Uint8Array(buf));
      setMessage(
        `پایگاه‌داده SQLite بازیابی و به نسخه ${toPersianDigits(res.restoredVersion)} مهاجرت ایمن شد (${toPersianDigits(res.recordTotal)} رکورد).`
      );
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'فایل SQLite نامعتبر است');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-100">ماژول ۳: آرشیف هوشمند، پشتیبان‌گیری و بازیابی</h1>
        <p className="text-xs text-slate-400 mt-1">
          پیشنهادهای خودکار بایگانی، پشتیبان‌گیری رمزنگاری‌شده AES-256-GCM و بازیابی تاییدشده بدون حذف فایل‌های اصلی
        </p>
      </div>

      {message && (
        <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3.5 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{message}</span>
        </div>
      )}
      {error && (
        <div className="rounded-xl border border-rose-500/35 bg-rose-500/10 p-3.5 text-xs text-rose-200 flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Backup & Restore Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Create Backup */}
        <form
          onSubmit={handleEncryptedBackup}
          className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Lock className="h-4 w-4 text-emerald-400" />
              <span>ایجاد پشتیبان ایمن (AES-256-GCM)</span>
            </h2>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            کل پایگاه‌داده SQLite با کلید مشتق‌شده PBKDF2-SHA256 رمزنگاری و همراه با امضای یکپارچگی ذخیره می‌شود.
          </p>

          <input
            type="password"
            value={backupPassword}
            onChange={(e) => setBackupPassword(e.target.value)}
            placeholder="رمز عبور پشتیبان (حداقل ۴ کاراکتر)"
            className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
          />

          <div className="flex flex-wrap gap-2.5">
            <button
              type="submit"
              disabled={busy}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              <Download className="h-4 w-4" />
              <span>دانلود پشتیبان رمزنگاری‌شده (.novabak)</span>
            </button>

            <button
              type="button"
              onClick={handleRawSqliteExport}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-[#132540] px-4 text-sm font-medium text-slate-200 hover:border-amber-500/40"
            >
              <Download className="h-4 w-4 text-amber-400" />
              <span>خروجی SQLite (.sqlite)</span>
            </button>
          </div>
        </form>

        {/* Restore Backup */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] p-5 space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <RotateCcw className="h-4 w-4 text-amber-400" />
            <span>بازیابی تاییدشده نسخه پشتیبان</span>
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            پیش از اعمال بازیابی، سلامت SQLite و امضای SHA-256 بررسی می‌شود و در صورت خطا پایگاه‌داده فعلی دست‌نخورده می‌ماند.
          </p>

          <input
            type="password"
            value={restorePassword}
            onChange={(e) => setRestorePassword(e.target.value)}
            placeholder="رمز عبور فایل پشتیبان رمزنگاری‌شده"
            className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-[#07101f] px-3.5 text-sm text-slate-100"
          />

          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              disabled={busy}
              onClick={() => restoreEncryptedRef.current?.click()}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 text-sm font-medium text-emerald-300 hover:bg-emerald-500/20"
            >
              <Upload className="h-4 w-4" />
              <span>بازیابی از فایل .novabak</span>
            </button>

            <button
              type="button"
              disabled={busy}
              onClick={() => restoreSqliteRef.current?.click()}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-[#132540] px-4 text-sm font-medium text-slate-200 hover:border-amber-500/40"
            >
              <Upload className="h-4 w-4 text-amber-400" />
              <span>بازیابی از فایل .sqlite</span>
            </button>

            <input
              ref={restoreEncryptedRef}
              type="file"
              accept=".novabak,.json"
              className="hidden"
              onChange={(e) => {
                void handleEncryptedRestoreFile(e.target.files);
                e.target.value = '';
              }}
            />
            <input
              ref={restoreSqliteRef}
              type="file"
              accept=".sqlite,.db"
              className="hidden"
              onChange={(e) => {
                void handleRawSqliteRestore(e.target.files);
                e.target.value = '';
              }}
            />
          </div>
        </div>
      </section>

      {/* Tabs: Suggestions / Archived Items / Audit Logs */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex rounded-xl bg-[#0d1b30] p-1 border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('suggestions')}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-medium ${
                activeTab === 'suggestions' ? 'bg-emerald-600 text-white' : 'text-slate-300'
              }`}
            >
              پیشنهادهای هوشمند ({toPersianDigits(suggestions.length)})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('archived')}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-medium ${
                activeTab === 'archived' ? 'bg-emerald-600 text-white' : 'text-slate-300'
              }`}
            >
              موارد بایگانی‌شده ({toPersianDigits(archivedMemories.length + archivedDocs.length)})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-medium ${
                activeTab === 'logs' ? 'bg-emerald-600 text-white' : 'text-slate-300'
              }`}
            >
              تاریخچه عملیات ({toPersianDigits(logs.length)})
            </button>
          </div>

          {activeTab === 'suggestions' && suggestions.length > 0 && (
            <button
              type="button"
              disabled={busy}
              onClick={handleRunSmartArchive}
              className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-amber-500/20 border border-amber-500/40 px-4 text-xs font-semibold text-amber-200 hover:bg-amber-500/30"
            >
              <Archive className="h-4 w-4" />
              <span>اجرای آرشیف هوشمند ({toPersianDigits(suggestions.length)} مورد)</span>
            </button>
          )}
        </div>

        {activeTab === 'suggestions' && (
          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] divide-y divide-slate-800">
            {suggestions.length === 0 ? (
              <p className="p-6 text-sm text-slate-400">
                در حال حاضر مورد قدیمی، تکراری یا حجیم بدون استفاده برای آرشیف پیشنهاد نشده است.
              </p>
            ) : (
              suggestions.map((s) => (
                <div key={s.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-slate-100">{s.title}</div>
                    <div className="text-xs text-slate-400 mt-1">
                      {s.targetType === 'memory' ? 'حافظه' : 'سند'} · {s.reason}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs tabular-nums text-amber-300">{formatBytesDari(s.reclaimableBytes)}</span>
                    <button
                      type="button"
                      onClick={() => runSmartArchiveBatch([s]).then(onRefresh)}
                      className="min-h-[38px] rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 text-xs font-medium text-emerald-300 hover:bg-emerald-500/20"
                    >
                      انتقال به آرشیف
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'archived' && (
          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] divide-y divide-slate-800">
            {archivedMemories.length === 0 && archivedDocs.length === 0 ? (
              <p className="p-6 text-sm text-slate-400">مورد بایگانی‌شده‌ای وجود ندارد.</p>
            ) : (
              <>
                {archivedMemories.map((m) => (
                  <div key={`am-${m.id}`} className="p-4 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-100">{m.title}</div>
                      <div className="text-xs text-slate-400">حافظه بایگانی‌شده · {m.category}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => updateMemory(m.id, { isArchived: false, changeNote: 'بازگردانی از آرشیف' }).then(onRefresh)}
                      className="min-h-[38px] rounded-lg border border-slate-700 px-3 text-xs text-emerald-300 hover:bg-slate-800"
                    >
                      بازگردانی
                    </button>
                  </div>
                ))}
                {archivedDocs.map((d) => (
                  <div key={`ad-${d.id}`} className="p-4 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-100">{d.title}</div>
                      <div className="text-xs text-slate-400 font-mono-tabular">
                        سند بایگانی‌شده · {d.fileName}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => updateDocument(d.id, { isArchived: false }).then(onRefresh)}
                      className="min-h-[38px] rounded-lg border border-slate-700 px-3 text-xs text-emerald-300 hover:bg-slate-800"
                    >
                      بازگردانی
                    </button>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="rounded-2xl border border-slate-800 bg-[#0d1b30] divide-y divide-slate-800">
            {logs.map((log) => (
              <div key={log.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-semibold text-slate-100">{log.targetRef}</div>
                  <div className="text-xs text-slate-400 mt-0.5">{log.details}</div>
                </div>
                <div className="text-left shrink-0">
                  <div className="text-xs text-emerald-300">{log.status}</div>
                  <div className="text-[11px] text-slate-500 tabular-nums">{formatDateDari(log.createdAt)}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
